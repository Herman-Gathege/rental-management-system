--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Debian 15.13-1.pgdg130+1)
-- Dumped by pg_dump version 15.13 (Debian 15.13-1.pgdg130+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO rental_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.audit_logs (
    id character varying NOT NULL,
    organization_id character varying,
    user_id character varying,
    action character varying NOT NULL,
    entity_type character varying NOT NULL,
    entity_id character varying NOT NULL,
    description character varying NOT NULL,
    old_values text,
    new_values text,
    created_at timestamp without time zone,
    ip_address character varying
);


ALTER TABLE public.audit_logs OWNER TO rental_user;

--
-- Name: charges; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.charges (
    id character varying NOT NULL,
    organization_id character varying NOT NULL,
    lease_id character varying NOT NULL,
    amount numeric(10,2) NOT NULL,
    due_date date NOT NULL,
    billing_month date NOT NULL,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp without time zone,
    amount_paid numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    charge_type character varying NOT NULL
);


ALTER TABLE public.charges OWNER TO rental_user;

--
-- Name: checklist_item_templates; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.checklist_item_templates (
    id character varying NOT NULL,
    organization_id character varying NOT NULL,
    item_name character varying NOT NULL,
    sort_order integer DEFAULT 0,
    is_default boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone
);


ALTER TABLE public.checklist_item_templates OWNER TO rental_user;

--
-- Name: expense_attachments; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.expense_attachments (
    id character varying NOT NULL,
    expense_id character varying NOT NULL,
    filename character varying,
    file_url character varying NOT NULL,
    uploaded_by character varying,
    created_at timestamp without time zone
);


ALTER TABLE public.expense_attachments OWNER TO rental_user;

--
-- Name: expense_categories; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.expense_categories (
    id character varying NOT NULL,
    organization_id character varying NOT NULL,
    name character varying NOT NULL,
    description character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.expense_categories OWNER TO rental_user;

--
-- Name: expenses; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.expenses (
    id character varying NOT NULL,
    organization_id character varying NOT NULL,
    property_id character varying NOT NULL,
    unit_id character varying,
    vendor_id character varying,
    category_id character varying NOT NULL,
    created_by character varying NOT NULL,
    approved_by character varying,
    title character varying NOT NULL,
    description text,
    amount numeric(12,2) NOT NULL,
    expense_date date NOT NULL,
    payment_method character varying,
    reference_number character varying,
    status character varying DEFAULT 'draft'::character varying NOT NULL,
    receipt_number character varying,
    notes text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.expenses OWNER TO rental_user;

--
-- Name: inspection_items; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.inspection_items (
    id character varying NOT NULL,
    inspection_id character varying NOT NULL,
    item_name character varying NOT NULL,
    sort_order integer DEFAULT 0,
    condition character varying,
    comments text,
    photo_urls text DEFAULT '[]'::text,
    deduction_amount numeric(12,2) DEFAULT '0'::numeric,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.inspection_items OWNER TO rental_user;

--
-- Name: inspection_notes; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.inspection_notes (
    id character varying NOT NULL,
    inspection_id character varying NOT NULL,
    user_id character varying,
    note text NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.inspection_notes OWNER TO rental_user;

--
-- Name: lease_inspections; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.lease_inspections (
    id character varying NOT NULL,
    lease_id character varying NOT NULL,
    inspection_type character varying NOT NULL,
    inspection_date date,
    inspector_user_id character varying,
    tenant_signature_data text,
    tenant_signed_name character varying,
    tenant_signed_at timestamp without time zone,
    status character varying DEFAULT 'draft'::character varying,
    total_deduction_amount numeric(12,2) DEFAULT '0'::numeric,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deposit_held numeric(12,2),
    deposit_refunded numeric(12,2),
    deposit_shortfall numeric(12,2)
);


ALTER TABLE public.lease_inspections OWNER TO rental_user;

--
-- Name: leases; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.leases (
    id character varying NOT NULL,
    organization_id character varying NOT NULL,
    unit_id character varying NOT NULL,
    tenant_id character varying NOT NULL,
    start_date date NOT NULL,
    end_date date,
    rent_amount numeric(12,2) NOT NULL,
    deposit_amount numeric(12,2),
    billing_day integer DEFAULT 1,
    status character varying DEFAULT 'active'::character varying,
    created_at timestamp without time zone,
    move_in_date date,
    signed_on_behalf_of character varying,
    signed_lease_urls json,
    custom_fields json
);


ALTER TABLE public.leases OWNER TO rental_user;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.messages (
    id character varying NOT NULL,
    organization_id character varying NOT NULL,
    phone_number character varying NOT NULL,
    direction character varying NOT NULL,
    message_type character varying DEFAULT 'notification'::character varying NOT NULL,
    content text NOT NULL,
    template_name character varying,
    status character varying DEFAULT 'queued'::character varying NOT NULL,
    provider_message_id character varying,
    error_message text,
    channel character varying DEFAULT 'whatsapp'::character varying NOT NULL,
    triggered_by_user_id character varying,
    tenant_id character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    ticket_id character varying
);


ALTER TABLE public.messages OWNER TO rental_user;

--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.notification_preferences (
    id character varying NOT NULL,
    organization_id character varying NOT NULL,
    user_id character varying NOT NULL,
    email_enabled boolean DEFAULT false NOT NULL,
    whatsapp_enabled boolean DEFAULT true NOT NULL,
    sms_enabled boolean DEFAULT false NOT NULL,
    in_app_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.notification_preferences OWNER TO rental_user;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.notifications (
    id character varying NOT NULL,
    organization_id character varying NOT NULL,
    user_id character varying NOT NULL,
    title character varying NOT NULL,
    body text,
    notification_type character varying NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.notifications OWNER TO rental_user;

--
-- Name: organization_invitations; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.organization_invitations (
    id character varying NOT NULL,
    email character varying NOT NULL,
    role_id character varying,
    organization_id character varying,
    token character varying NOT NULL,
    status character varying,
    created_at timestamp without time zone,
    phone character varying
);


ALTER TABLE public.organization_invitations OWNER TO rental_user;

--
-- Name: organization_members; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.organization_members (
    id character varying NOT NULL,
    user_id character varying,
    organization_id character varying,
    role_id character varying,
    created_at timestamp without time zone
);


ALTER TABLE public.organization_members OWNER TO rental_user;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.organizations (
    id character varying NOT NULL,
    name character varying NOT NULL,
    owner_id character varying NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.organizations OWNER TO rental_user;

--
-- Name: otp_verifications; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.otp_verifications (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    purpose character varying DEFAULT 'phone_verification'::character varying NOT NULL,
    phone character varying,
    code_hash character varying NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_sent_at timestamp without time zone,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.otp_verifications OWNER TO rental_user;

--
-- Name: password_history; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.password_history (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    password_hash character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.password_history OWNER TO rental_user;

--
-- Name: payment_review_items; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.payment_review_items (
    id character varying NOT NULL,
    organization_id character varying NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_date date,
    reference character varying,
    payer_phone character varying,
    payer_name character varying,
    raw_transaction text,
    tenant_id character varying,
    lease_id character varying,
    status character varying DEFAULT 'pending_review'::character varying NOT NULL,
    flag_reason character varying NOT NULL,
    notes text,
    resolved_at timestamp without time zone,
    resolved_by_user_id character varying,
    resolution_payment_id character varying,
    rejection_reason character varying,
    created_at timestamp without time zone DEFAULT now(),
    created_by_user_id character varying,
    source character varying,
    source_message_id character varying,
    extracted_reference character varying,
    extracted_amount numeric(10,2),
    message_timestamp timestamp without time zone,
    payer_phone_hash character varying(64)
);


ALTER TABLE public.payment_review_items OWNER TO rental_user;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.payments (
    id character varying NOT NULL,
    organization_id character varying NOT NULL,
    tenant_id character varying NOT NULL,
    lease_id character varying NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_method character varying DEFAULT 'cash'::character varying NOT NULL,
    reference character varying,
    payment_date date NOT NULL,
    created_at timestamp without time zone,
    payment_type character varying NOT NULL
);


ALTER TABLE public.payments OWNER TO rental_user;

--
-- Name: properties; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.properties (
    id character varying NOT NULL,
    name character varying NOT NULL,
    address character varying NOT NULL,
    city character varying NOT NULL,
    country character varying NOT NULL,
    organization_id character varying,
    created_at timestamp without time zone
);


ALTER TABLE public.properties OWNER TO rental_user;

--
-- Name: property_finance_managers; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.property_finance_managers (
    id character varying NOT NULL,
    property_id character varying,
    user_id character varying
);


ALTER TABLE public.property_finance_managers OWNER TO rental_user;

--
-- Name: property_managers; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.property_managers (
    id character varying NOT NULL,
    property_id character varying,
    user_id character varying
);


ALTER TABLE public.property_managers OWNER TO rental_user;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.roles (
    id character varying NOT NULL,
    name character varying NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.roles OWNER TO rental_user;

--
-- Name: tenant_documents; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.tenant_documents (
    id character varying NOT NULL,
    tenant_id character varying NOT NULL,
    document_type character varying NOT NULL,
    file_url character varying NOT NULL,
    original_filename character varying,
    uploaded_by_user_id character varying,
    uploaded_at timestamp without time zone
);


ALTER TABLE public.tenant_documents OWNER TO rental_user;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.tenants (
    id character varying NOT NULL,
    organization_id character varying NOT NULL,
    full_name character varying NOT NULL,
    email character varying,
    phone character varying NOT NULL,
    id_number character varying,
    emergency_contact character varying,
    created_at timestamp without time zone,
    alternative_phone character varying,
    next_of_kin_name character varying,
    next_of_kin_relationship character varying,
    next_of_kin_phone character varying,
    next_of_kin_alt_phone character varying,
    next_of_kin_email character varying,
    employer_name character varying,
    employer_location character varying,
    employer_phone character varying,
    employer_email character varying,
    user_id character varying,
    phone_hash character varying(64),
    alternative_phone_hash character varying(64),
    email_hash character varying(64),
    id_number_hash character varying(64)
);


ALTER TABLE public.tenants OWNER TO rental_user;

--
-- Name: ticket_assignments; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.ticket_assignments (
    id character varying NOT NULL,
    ticket_id character varying NOT NULL,
    assigned_from character varying,
    assigned_to character varying,
    reason text,
    assigned_at timestamp without time zone
);


ALTER TABLE public.ticket_assignments OWNER TO rental_user;

--
-- Name: ticket_attachments; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.ticket_attachments (
    id character varying NOT NULL,
    ticket_id character varying NOT NULL,
    uploaded_by character varying,
    file_name character varying,
    file_url character varying NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.ticket_attachments OWNER TO rental_user;

--
-- Name: ticket_messages; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.ticket_messages (
    id character varying NOT NULL,
    ticket_id character varying NOT NULL,
    sender_id character varying,
    message text NOT NULL,
    is_internal boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone,
    recipient_id character varying
);


ALTER TABLE public.ticket_messages OWNER TO rental_user;

--
-- Name: tickets; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.tickets (
    id character varying NOT NULL,
    organization_id character varying NOT NULL,
    tenant_id character varying,
    source_phone character varying,
    source_message_id character varying,
    description text NOT NULL,
    status character varying DEFAULT 'open'::character varying NOT NULL,
    source character varying DEFAULT 'whatsapp'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    property_id character varying,
    unit_id character varying,
    created_by character varying,
    assigned_to character varying,
    priority character varying DEFAULT 'medium'::character varying NOT NULL,
    category character varying,
    opened_at timestamp without time zone,
    resolved_at timestamp without time zone,
    closed_at timestamp without time zone,
    title character varying NOT NULL
);


ALTER TABLE public.tickets OWNER TO rental_user;

--
-- Name: units; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.units (
    id character varying NOT NULL,
    property_id character varying NOT NULL,
    name character varying NOT NULL,
    description character varying,
    bedrooms integer,
    bathrooms integer,
    size_sqm double precision,
    rent_amount numeric(10,2) NOT NULL,
    is_active boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.units OWNER TO rental_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.users (
    id character varying NOT NULL,
    email character varying NOT NULL,
    password_hash character varying NOT NULL,
    is_active boolean,
    refresh_token character varying,
    reset_token character varying,
    reset_token_expiry timestamp without time zone,
    role_id character varying,
    full_name character varying,
    phone character varying,
    phone_verified boolean NOT NULL,
    failed_login_count integer DEFAULT 0 NOT NULL,
    locked_until timestamp without time zone
);


ALTER TABLE public.users OWNER TO rental_user;

--
-- Name: vendors; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.vendors (
    id character varying NOT NULL,
    organization_id character varying NOT NULL,
    vendor_name character varying NOT NULL,
    contact_person character varying,
    phone character varying,
    email character varying,
    kra_pin character varying,
    address character varying,
    notes character varying,
    created_at timestamp without time zone
);


ALTER TABLE public.vendors OWNER TO rental_user;

--
-- Name: whatsapp_integrations; Type: TABLE; Schema: public; Owner: rental_user
--

CREATE TABLE public.whatsapp_integrations (
    id character varying NOT NULL,
    organization_id character varying NOT NULL,
    meta_phone_number_id character varying NOT NULL,
    meta_business_account_id character varying,
    environment character varying DEFAULT 'sandbox'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.whatsapp_integrations OWNER TO rental_user;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.alembic_version (version_num) FROM stdin;
f8a1b2c3d4e5
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.audit_logs (id, organization_id, user_id, action, entity_type, entity_id, description, old_values, new_values, created_at, ip_address) FROM stdin;
81ce8f1f-05a4-42ce-8d95-09b347d984ff	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	login	user	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	User logged in: demo@alphaone.africa	\N	\N	2026-09-12 06:46:11.419123	172.18.0.1
fc697390-2958-49e4-8d23-2f4cde638598	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	login	user	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	User logged in: demo@alphaone.africa	\N	\N	2026-09-12 06:46:51.303482	172.18.0.1
7188c20d-45cc-4834-9296-ac7763b84553	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	create	property	0d4dae1c-05dc-4bdf-8731-cc09caabdc0a	Created property: Riverside Apartments	\N	{"name": "Riverside Apartments", "address": "00100-177", "city": "nairobi", "country": "Kenya"}	2026-09-12 06:50:37.007069	\N
b4e7c84e-9d45-4629-a99b-d61dc47508cd	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	bulk_create	unit	d109e97a-fc06-4b47-8728-cbd4f1f39b31	Bulk unit upload: 5 imported, 0 skipped, 5 total	\N	{"imported_count": 5, "skipped_count": 0, "total_rows": 5}	2026-09-12 06:54:48.298117	\N
17b45d83-bcb2-42ce-9ab9-eed3ba3ec620	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	bulk_create	tenant	04e075eb-125d-44bd-9b6d-9f6b7887f040	Bulk tenant upload: 5 imported, 0 skipped, 5 total	\N	{"imported_count": 5, "skipped_count": 0, "total_rows": 5}	2026-09-12 06:58:50.996898	\N
c726aa6c-bda4-40be-9dc6-80e634a183be	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	billing	charge	batch	Generated 5 monthly charges for 2026-09-01	\N	\N	2026-09-12 07:00:23.256347	\N
c458d0ab-d0c5-4b2b-b83d-14e752f14e33	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	payment	payment	339a0b0c-a4f3-4cd6-b22c-2270593f35f7	Batch payment of 12000.0 (deposit) recorded for Grace Mwangi via mpesa (ref UI7BD6170U)	\N	{"amount": 12000.0, "payment_method": "mpesa", "payment_type": "deposit", "reference": "UI7BD6170U", "tenant": "Grace Mwangi", "batch": true, "split_of_row_amount": null}	2026-09-12 08:10:13.079236	\N
63c9221e-5ff5-47ec-8ca0-1dc8063fea7a	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	apply_review	payment_review	d7f3d4f1-6cd7-4b18-bb56-564c72df4e0e	Auto-applied review item — payment 339a0b0c-a4f3-4cd6-b22c-2270593f35f7 was recorded with the same reference (UI7BD6170U)	\N	{"payment_id": "339a0b0c-a4f3-4cd6-b22c-2270593f35f7", "reference": "UI7BD6170U", "auto_resolved_by": "payment_commit"}	2026-09-12 08:10:13.079243	\N
603c2b48-df57-4195-a19a-97cd2aa5b529	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	payment	payment	56ec1c5d-719d-4228-86e6-fd56e97f6da8	Batch payment of 15000.0 (deposit) recorded for David Kimani via mpesa (ref UI7FK5VY2Z)	\N	{"amount": 15000.0, "payment_method": "mpesa", "payment_type": "deposit", "reference": "UI7FK5VY2Z", "tenant": "David Kimani", "batch": true, "split_of_row_amount": 30000.0}	2026-09-12 08:10:13.11973	\N
15b869d7-87c6-429c-a42f-bcb1170d5887	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	payment	payment	7f333d29-6d88-45ca-8011-89fed12006b3	Batch payment of 15000.0 (rent) recorded for David Kimani via mpesa (ref UI7FK5VY2Z)	\N	{"amount": 15000.0, "payment_method": "mpesa", "payment_type": "rent", "reference": "UI7FK5VY2Z", "tenant": "David Kimani", "batch": true, "split_of_row_amount": 30000.0}	2026-09-12 08:10:13.131404	\N
ed59e3b1-ebcd-4127-ac65-288122f46a74	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	apply_review	payment_review	3d393240-f6e4-4e0e-aa8a-28ed3c6cd231	Auto-applied review item — payment 56ec1c5d-719d-4228-86e6-fd56e97f6da8 was recorded with the same reference (UI7FK5VY2Z)	\N	{"payment_id": "56ec1c5d-719d-4228-86e6-fd56e97f6da8", "reference": "UI7FK5VY2Z", "auto_resolved_by": "payment_commit"}	2026-09-12 08:10:13.131411	\N
514f91bd-42f8-457d-8803-798128063b21	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	payment	payment	f713c474-8a9e-40b9-903e-8b2407c3bc90	Batch payment of 18000.0 (deposit) recorded for Sarah Wanjiku via mpesa (ref UI6QI57NHU)	\N	{"amount": 18000.0, "payment_method": "mpesa", "payment_type": "deposit", "reference": "UI6QI57NHU", "tenant": "Sarah Wanjiku", "batch": true, "split_of_row_amount": 25000.0}	2026-09-12 08:10:13.137246	\N
659b4753-183f-4ac6-81e5-931eb70989cf	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	payment	payment	396af59c-b59a-4e51-8ac1-5a9d160f8526	Batch payment of 7000.0 (rent) recorded for Sarah Wanjiku via mpesa (ref UI6QI57NHU)	\N	{"amount": 7000.0, "payment_method": "mpesa", "payment_type": "rent", "reference": "UI6QI57NHU", "tenant": "Sarah Wanjiku", "batch": true, "split_of_row_amount": 25000.0}	2026-09-12 08:10:13.149275	\N
08d0a82e-52dd-4d9b-a7ba-d63a5bcc58bc	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	apply_review	payment_review	002df80c-5b70-4fb7-b1ba-6ae90c67702c	Auto-applied review item — payment f713c474-8a9e-40b9-903e-8b2407c3bc90 was recorded with the same reference (UI6QI57NHU)	\N	{"payment_id": "f713c474-8a9e-40b9-903e-8b2407c3bc90", "reference": "UI6QI57NHU", "auto_resolved_by": "payment_commit"}	2026-09-12 08:10:13.149281	\N
82af61f5-9fd5-4c23-87d0-eebc1b69c713	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	payment	payment	7f29781d-8441-44b8-b870-53e6ac3fb503	Batch payment of 10000.0 (rent) recorded for Mary Achieng via mpesa (ref UMAC2R6HGB)	\N	{"amount": 10000.0, "payment_method": "mpesa", "payment_type": "rent", "reference": "UMAC2R6HGB", "tenant": "Mary Achieng", "batch": true, "split_of_row_amount": null}	2026-09-12 08:10:13.173198	\N
9dc7dc97-a2db-4d15-8ca8-aebfcd5c6881	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	apply_review	payment_review	1b5ba6c7-8f76-4100-91e7-c85b22961931	Auto-applied review item — payment 7f29781d-8441-44b8-b870-53e6ac3fb503 was recorded with the same reference (UMAC2R6HGB)	\N	{"payment_id": "7f29781d-8441-44b8-b870-53e6ac3fb503", "reference": "UMAC2R6HGB", "auto_resolved_by": "payment_commit"}	2026-09-12 08:10:13.173201	\N
a209fd7f-7e5a-43f9-b43a-7390334061b9	20ff8602-5693-4418-a2cc-69001487f42c	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	save_for_review	payment_review	65da70e9-8e7d-46a3-80d4-ab1e1519eb66	Saved 0 payment(s) for later review (skipped 1)	\N	{"saved": 0, "skipped": 1}	2026-09-12 08:10:15.725841	\N
22dc2419-860c-4d9f-a1c1-50494bec43f4	20ff8602-5693-4418-a2cc-69001487f42c	f4a4cc0f-93a7-4600-9ea7-2fd3496c2468	login	user	f4a4cc0f-93a7-4600-9ea7-2fd3496c2468	User logged in: tenant@alphaone.africa	\N	\N	2026-09-12 08:23:28.993188	172.18.0.1
957b0034-4789-4850-b010-e587ec2bb3bb	20ff8602-5693-4418-a2cc-69001487f42c	f4a4cc0f-93a7-4600-9ea7-2fd3496c2468	login	user	f4a4cc0f-93a7-4600-9ea7-2fd3496c2468	User logged in: tenant@alphaone.africa	\N	\N	2026-09-12 08:24:50.686909	172.18.0.1
\.


--
-- Data for Name: charges; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.charges (id, organization_id, lease_id, amount, due_date, billing_month, status, created_at, amount_paid, charge_type) FROM stdin;
03ff24fc-fbb2-4eaa-a689-be1d5f031d3b	20ff8602-5693-4418-a2cc-69001487f42c	25afd600-2d2d-4b34-9869-ed60fc0f5a36	20000.00	2026-09-12	2026-09-12	pending	2026-09-12 06:58:50.970014	0.00	deposit
a3f96e72-1663-4435-bc37-ed36bfef2b80	20ff8602-5693-4418-a2cc-69001487f42c	7e4b71ac-4c99-4031-8066-4ae95ba6fa51	12000.00	2026-09-01	2026-09-01	overdue	2026-09-12 07:00:23.221686	0.00	rent
c7818825-66d8-403f-8be9-a8ab068718df	20ff8602-5693-4418-a2cc-69001487f42c	25afd600-2d2d-4b34-9869-ed60fc0f5a36	20000.00	2026-09-01	2026-09-01	overdue	2026-09-12 07:00:23.221704	0.00	rent
2cf5fc7f-5987-4dab-ae11-a4affc19ba2c	20ff8602-5693-4418-a2cc-69001487f42c	443b9454-4c42-4d54-a9d0-2a0fffe546a9	10000.00	2026-09-12	2026-09-12	paid	2026-09-12 06:58:50.983352	10000.00	deposit
207af267-1d82-4476-81d2-75a38e70e478	20ff8602-5693-4418-a2cc-69001487f42c	df06ed36-4ac4-4ff1-ad7e-fef330fa7753	15000.00	2026-09-12	2026-09-12	paid	2026-09-12 06:58:50.92142	15000.00	deposit
3f669cfe-2d8f-48ea-b3cc-3abd6dcb3540	20ff8602-5693-4418-a2cc-69001487f42c	df06ed36-4ac4-4ff1-ad7e-fef330fa7753	15000.00	2026-09-01	2026-09-01	paid	2026-09-12 07:00:23.221701	15000.00	rent
a13133d4-63cd-4c52-b324-1b425db852b8	20ff8602-5693-4418-a2cc-69001487f42c	7e4b71ac-4c99-4031-8066-4ae95ba6fa51	12000.00	2026-09-12	2026-09-12	paid	2026-09-12 06:58:50.864065	12000.00	deposit
d97c62ad-c6b6-46eb-bfb2-cce33e9bdc01	20ff8602-5693-4418-a2cc-69001487f42c	04f7d786-d008-4578-9d0c-f1d672663846	18000.00	2026-09-01	2026-09-01	partial	2026-09-12 07:00:23.221703	7000.00	rent
deff804e-dd21-4a80-8d68-1d5cdc06be58	20ff8602-5693-4418-a2cc-69001487f42c	443b9454-4c42-4d54-a9d0-2a0fffe546a9	10000.00	2026-09-01	2026-09-01	paid	2026-09-12 07:00:23.221706	10000.00	rent
ecf4d7bc-a241-4301-b6f4-dc2e725fb6cc	20ff8602-5693-4418-a2cc-69001487f42c	04f7d786-d008-4578-9d0c-f1d672663846	18000.00	2026-09-12	2026-09-12	paid	2026-09-12 06:58:50.951503	18000.00	deposit
\.


--
-- Data for Name: checklist_item_templates; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.checklist_item_templates (id, organization_id, item_name, sort_order, is_default, is_active, created_at) FROM stdin;
46091b5f-e275-4171-a11f-d83cd1ee335b	20ff8602-5693-4418-a2cc-69001487f42c	Doors, windows, glass, handles, hinges, and locks	0	t	t	2026-09-12 06:41:13.577322
dc0e9e8d-ad6d-4d2b-9fc6-7e9851cf3496	20ff8602-5693-4418-a2cc-69001487f42c	Floor finishes (tiles/terrazzo)	1	t	t	2026-09-12 06:41:13.577327
44622cfc-dd0b-4a25-b132-f29696aa3c77	20ff8602-5693-4418-a2cc-69001487f42c	Walls and paint finish	2	t	t	2026-09-12 06:41:13.577329
ff37d70a-a72e-469c-b863-5bfb9f51c94d	20ff8602-5693-4418-a2cc-69001487f42c	Door locks and keys issued (list keys)	3	t	t	2026-09-12 06:41:13.57733
a19efa53-5d16-4a57-a469-9b3347012783	20ff8602-5693-4418-a2cc-69001487f42c	Electricity switches, sockets, and light fittings	4	t	t	2026-09-12 06:41:13.577346
58c92d74-0d69-493e-ad44-d4a541e508bb	20ff8602-5693-4418-a2cc-69001487f42c	Water taps and plumbing visible fittings (note any defects/leaks)	5	t	t	2026-09-12 06:41:13.577348
da4ea4e0-6a30-46e0-b57d-cc1f9d855db4	20ff8602-5693-4418-a2cc-69001487f42c	Hot water heater / shower	6	t	t	2026-09-12 06:41:13.577349
c64702d0-75b7-4e84-9071-b11a0cb80a2a	20ff8602-5693-4418-a2cc-69001487f42c	Sinks and drain points (note any defects/leaks)	7	t	t	2026-09-12 06:41:13.57735
957f3aec-29e2-4d0d-8843-535a72b40505	20ff8602-5693-4418-a2cc-69001487f42c	Kitchen cabinets/cupboards, drawers, and shelves	8	t	t	2026-09-12 06:41:13.577351
48805527-7d25-41b1-9f19-ff0f1f11bbf6	20ff8602-5693-4418-a2cc-69001487f42c	Bedroom wardrobes, drawers, and shelves	9	t	t	2026-09-12 06:41:13.577352
62fcd261-4c46-499d-9238-ce41d8428091	20ff8602-5693-4418-a2cc-69001487f42c	Bathroom and bedroom mirrors	10	t	t	2026-09-12 06:41:13.577353
867def79-a408-47d0-9f03-15a2a8f273c8	20ff8602-5693-4418-a2cc-69001487f42c	Bathroom soap holder, toilet paper holder, and robe/towel holders	11	t	t	2026-09-12 06:41:13.577354
7bdc895c-4ccf-4b8a-8a59-493192ff5a20	20ff8602-5693-4418-a2cc-69001487f42c	Toilet (bowl, cistern, and flushing mechanism) (note any defects/leaks)	12	t	t	2026-09-12 06:41:13.577355
\.


--
-- Data for Name: expense_attachments; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.expense_attachments (id, expense_id, filename, file_url, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.expense_categories (id, organization_id, name, description, is_active, created_at, updated_at) FROM stdin;
616db088-c319-4b0d-b64c-782145bd6d90	20ff8602-5693-4418-a2cc-69001487f42c	Repairs	\N	t	2026-09-12 06:41:13.646233	2026-09-12 06:41:13.646237
c10ca2d5-116d-45af-bd72-fe086509834b	20ff8602-5693-4418-a2cc-69001487f42c	Maintenance	\N	t	2026-09-12 06:41:13.646239	2026-09-12 06:41:13.64624
f2967cec-c147-40b8-bf03-8b6d1ea9ffde	20ff8602-5693-4418-a2cc-69001487f42c	Cleaning	\N	t	2026-09-12 06:41:13.646241	2026-09-12 06:41:13.646242
b222e714-a78c-4631-9bef-cce6ecc8bcc5	20ff8602-5693-4418-a2cc-69001487f42c	Water	\N	t	2026-09-12 06:41:13.646243	2026-09-12 06:41:13.646244
06e9e528-1dd3-492b-b793-6ba2449fc850	20ff8602-5693-4418-a2cc-69001487f42c	Electricity	\N	t	2026-09-12 06:41:13.646245	2026-09-12 06:41:13.646246
847da9f8-c60b-4a86-b10a-94455a8422ec	20ff8602-5693-4418-a2cc-69001487f42c	Security	\N	t	2026-09-12 06:41:13.646247	2026-09-12 06:41:13.646247
b3c508bf-d466-4d29-a297-1a9f43d5bb9f	20ff8602-5693-4418-a2cc-69001487f42c	Salaries	\N	t	2026-09-12 06:41:13.646248	2026-09-12 06:41:13.646249
0b7c47b2-78b6-465b-a532-f5c7917154af	20ff8602-5693-4418-a2cc-69001487f42c	Marketing	\N	t	2026-09-12 06:41:13.64625	2026-09-12 06:41:13.646251
883bfd75-5a9f-4fd9-9405-e77c3b03fcf0	20ff8602-5693-4418-a2cc-69001487f42c	Internet	\N	t	2026-09-12 06:41:13.646252	2026-09-12 06:41:13.646253
6350e767-74d0-418a-9cf7-8e1ed5cc2b5b	20ff8602-5693-4418-a2cc-69001487f42c	Legal	\N	t	2026-09-12 06:41:13.646254	2026-09-12 06:41:13.646255
ffbc1e60-58e0-4677-80a6-a0ea31c436a8	20ff8602-5693-4418-a2cc-69001487f42c	Insurance	\N	t	2026-09-12 06:41:13.646256	2026-09-12 06:41:13.646257
55909f65-7890-4c48-9d4c-9d4e8850b4f6	20ff8602-5693-4418-a2cc-69001487f42c	Fuel	\N	t	2026-09-12 06:41:13.646257	2026-09-12 06:41:13.646258
76af5807-ca0d-4756-a9bc-117ddd613f25	20ff8602-5693-4418-a2cc-69001487f42c	Office Supplies	\N	t	2026-09-12 06:41:13.646259	2026-09-12 06:41:13.64626
b3a9ac46-8dab-40f3-8267-b2d44a94f5e9	20ff8602-5693-4418-a2cc-69001487f42c	Landscaping	\N	t	2026-09-12 06:41:13.646261	2026-09-12 06:41:13.646262
35ce357f-1eba-4fcc-939c-21e906f682e3	20ff8602-5693-4418-a2cc-69001487f42c	Waste Collection	\N	t	2026-09-12 06:41:13.646262	2026-09-12 06:41:13.646263
9461fd99-89d3-4bc5-a196-9d2be317e794	20ff8602-5693-4418-a2cc-69001487f42c	Other	\N	t	2026-09-12 06:41:13.646264	2026-09-12 06:41:13.646265
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.expenses (id, organization_id, property_id, unit_id, vendor_id, category_id, created_by, approved_by, title, description, amount, expense_date, payment_method, reference_number, status, receipt_number, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inspection_items; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.inspection_items (id, inspection_id, item_name, sort_order, condition, comments, photo_urls, deduction_amount, created_at, updated_at) FROM stdin;
4a4ac654-900e-44fa-a9b6-bf1f72ba6d1e	ab178146-f8c7-4fe0-a583-dcbba36160c5	Doors, windows, glass, handles, hinges, and locks	0	\N	\N	[]	0.00	2026-09-12 06:58:50.892117	2026-09-12 06:58:50.892121
a2066775-cbca-42bb-a35b-849b30f1ff9a	ab178146-f8c7-4fe0-a583-dcbba36160c5	Floor finishes (tiles/terrazzo)	1	\N	\N	[]	0.00	2026-09-12 06:58:50.892124	2026-09-12 06:58:50.892126
84070ab9-0a99-4f09-9a48-e54dec9328fb	ab178146-f8c7-4fe0-a583-dcbba36160c5	Walls and paint finish	2	\N	\N	[]	0.00	2026-09-12 06:58:50.892127	2026-09-12 06:58:50.892129
1057fccf-9902-4d42-b787-2a676620c145	ab178146-f8c7-4fe0-a583-dcbba36160c5	Door locks and keys issued (list keys)	3	\N	\N	[]	0.00	2026-09-12 06:58:50.89213	2026-09-12 06:58:50.892132
ee20b085-1927-4059-a2a4-f2d8782f90e2	ab178146-f8c7-4fe0-a583-dcbba36160c5	Electricity switches, sockets, and light fittings	4	\N	\N	[]	0.00	2026-09-12 06:58:50.892134	2026-09-12 06:58:50.892134
67e1a81b-0335-4aa1-82f6-f18cc0973f6a	ab178146-f8c7-4fe0-a583-dcbba36160c5	Water taps and plumbing visible fittings (note any defects/leaks)	5	\N	\N	[]	0.00	2026-09-12 06:58:50.892136	2026-09-12 06:58:50.892136
ce006ddb-661f-4d2f-b19b-8d07a73fb818	ab178146-f8c7-4fe0-a583-dcbba36160c5	Hot water heater / shower	6	\N	\N	[]	0.00	2026-09-12 06:58:50.892138	2026-09-12 06:58:50.892138
621cfac9-e410-46c6-8796-174c26f62dd4	ab178146-f8c7-4fe0-a583-dcbba36160c5	Sinks and drain points (note any defects/leaks)	7	\N	\N	[]	0.00	2026-09-12 06:58:50.89214	2026-09-12 06:58:50.89214
1338110a-cc58-4b9a-9a78-24706f2d041a	ab178146-f8c7-4fe0-a583-dcbba36160c5	Kitchen cabinets/cupboards, drawers, and shelves	8	\N	\N	[]	0.00	2026-09-12 06:58:50.892141	2026-09-12 06:58:50.892142
4c91be38-cdf6-47ea-8829-6a28642400cf	ab178146-f8c7-4fe0-a583-dcbba36160c5	Bedroom wardrobes, drawers, and shelves	9	\N	\N	[]	0.00	2026-09-12 06:58:50.892143	2026-09-12 06:58:50.892144
d71b098b-9bf5-4abf-993c-e203b55a6627	ab178146-f8c7-4fe0-a583-dcbba36160c5	Bathroom and bedroom mirrors	10	\N	\N	[]	0.00	2026-09-12 06:58:50.892145	2026-09-12 06:58:50.892146
be2deece-24f6-4071-a641-0a26a2b2b8e6	ab178146-f8c7-4fe0-a583-dcbba36160c5	Bathroom soap holder, toilet paper holder, and robe/towel holders	11	\N	\N	[]	0.00	2026-09-12 06:58:50.892147	2026-09-12 06:58:50.892148
dc1509f9-defe-4bf8-ae3b-c23ad8c53d7e	ab178146-f8c7-4fe0-a583-dcbba36160c5	Toilet (bowl, cistern, and flushing mechanism) (note any defects/leaks)	12	\N	\N	[]	0.00	2026-09-12 06:58:50.892149	2026-09-12 06:58:50.89215
57220393-fcd3-4aeb-8c0a-fa98706343c5	0a739530-6795-480d-baff-f57505ec7efa	Doors, windows, glass, handles, hinges, and locks	0	\N	\N	[]	0.00	2026-09-12 06:58:50.944095	2026-09-12 06:58:50.944099
41c3bf94-8001-4de3-a25d-77100913d232	0a739530-6795-480d-baff-f57505ec7efa	Floor finishes (tiles/terrazzo)	1	\N	\N	[]	0.00	2026-09-12 06:58:50.9441	2026-09-12 06:58:50.9441
5ab987ad-5dfd-4e0d-a7b5-608a4561821f	0a739530-6795-480d-baff-f57505ec7efa	Walls and paint finish	2	\N	\N	[]	0.00	2026-09-12 06:58:50.944101	2026-09-12 06:58:50.944101
a1e13534-5080-4dab-abb2-d76dc3f192d4	0a739530-6795-480d-baff-f57505ec7efa	Door locks and keys issued (list keys)	3	\N	\N	[]	0.00	2026-09-12 06:58:50.944102	2026-09-12 06:58:50.944102
8becf3d0-9ffb-47cb-bbe6-d9b57d8ededb	0a739530-6795-480d-baff-f57505ec7efa	Electricity switches, sockets, and light fittings	4	\N	\N	[]	0.00	2026-09-12 06:58:50.944103	2026-09-12 06:58:50.944103
8c1c282c-444c-4673-aca3-769bbfd0e5e9	0a739530-6795-480d-baff-f57505ec7efa	Water taps and plumbing visible fittings (note any defects/leaks)	5	\N	\N	[]	0.00	2026-09-12 06:58:50.944104	2026-09-12 06:58:50.944104
d4be9525-5283-4321-afaf-34dc1b03eb0f	0a739530-6795-480d-baff-f57505ec7efa	Hot water heater / shower	6	\N	\N	[]	0.00	2026-09-12 06:58:50.944104	2026-09-12 06:58:50.944105
7cb47c98-2ec4-4beb-ad91-b30c1c2033bd	0a739530-6795-480d-baff-f57505ec7efa	Sinks and drain points (note any defects/leaks)	7	\N	\N	[]	0.00	2026-09-12 06:58:50.944105	2026-09-12 06:58:50.944105
c850c9bb-486f-458c-9e59-7d2e6301117a	0a739530-6795-480d-baff-f57505ec7efa	Kitchen cabinets/cupboards, drawers, and shelves	8	\N	\N	[]	0.00	2026-09-12 06:58:50.944106	2026-09-12 06:58:50.944106
f0cd1c64-1c81-47ee-9dec-a1c04ff383e4	0a739530-6795-480d-baff-f57505ec7efa	Bedroom wardrobes, drawers, and shelves	9	\N	\N	[]	0.00	2026-09-12 06:58:50.944107	2026-09-12 06:58:50.944107
45d96372-28d4-4d67-af65-8a2c81689da5	0a739530-6795-480d-baff-f57505ec7efa	Bathroom and bedroom mirrors	10	\N	\N	[]	0.00	2026-09-12 06:58:50.944108	2026-09-12 06:58:50.944108
c489225f-532f-4d14-a042-fa7c828beedb	0a739530-6795-480d-baff-f57505ec7efa	Bathroom soap holder, toilet paper holder, and robe/towel holders	11	\N	\N	[]	0.00	2026-09-12 06:58:50.944109	2026-09-12 06:58:50.944109
9091e12b-4d49-4f28-94c9-75b42a2e284e	0a739530-6795-480d-baff-f57505ec7efa	Toilet (bowl, cistern, and flushing mechanism) (note any defects/leaks)	12	\N	\N	[]	0.00	2026-09-12 06:58:50.94411	2026-09-12 06:58:50.94411
4d699044-c013-4426-b139-10591103735f	c568f0d1-866e-40f3-9142-6883cacc65ae	Doors, windows, glass, handles, hinges, and locks	0	\N	\N	[]	0.00	2026-09-12 06:58:50.96503	2026-09-12 06:58:50.965035
5855d039-a54b-4a12-b9f4-3aed54a781aa	c568f0d1-866e-40f3-9142-6883cacc65ae	Floor finishes (tiles/terrazzo)	1	\N	\N	[]	0.00	2026-09-12 06:58:50.965036	2026-09-12 06:58:50.965037
6c6c144c-543c-4af6-8c73-96f5ff5fd136	c568f0d1-866e-40f3-9142-6883cacc65ae	Walls and paint finish	2	\N	\N	[]	0.00	2026-09-12 06:58:50.965038	2026-09-12 06:58:50.965038
9940763d-d7b5-49f3-a606-a252b4afb946	c568f0d1-866e-40f3-9142-6883cacc65ae	Door locks and keys issued (list keys)	3	\N	\N	[]	0.00	2026-09-12 06:58:50.965039	2026-09-12 06:58:50.96504
87a667e2-1282-4b91-8412-09f39038d23d	c568f0d1-866e-40f3-9142-6883cacc65ae	Electricity switches, sockets, and light fittings	4	\N	\N	[]	0.00	2026-09-12 06:58:50.96504	2026-09-12 06:58:50.965041
e301bde2-7120-4373-9079-94efce9354c6	c568f0d1-866e-40f3-9142-6883cacc65ae	Water taps and plumbing visible fittings (note any defects/leaks)	5	\N	\N	[]	0.00	2026-09-12 06:58:50.965042	2026-09-12 06:58:50.965043
b653eb73-4e21-4bce-9cf4-9f24484cf1ea	c568f0d1-866e-40f3-9142-6883cacc65ae	Hot water heater / shower	6	\N	\N	[]	0.00	2026-09-12 06:58:50.965043	2026-09-12 06:58:50.965044
e03636b8-463b-4453-a444-b0e252a5eae6	c568f0d1-866e-40f3-9142-6883cacc65ae	Sinks and drain points (note any defects/leaks)	7	\N	\N	[]	0.00	2026-09-12 06:58:50.965045	2026-09-12 06:58:50.965045
ac89a29f-c1d5-470b-bad1-8588751a3ef8	c568f0d1-866e-40f3-9142-6883cacc65ae	Kitchen cabinets/cupboards, drawers, and shelves	8	\N	\N	[]	0.00	2026-09-12 06:58:50.965046	2026-09-12 06:58:50.965047
b73ffc4b-1056-42eb-be21-61266518f295	c568f0d1-866e-40f3-9142-6883cacc65ae	Bedroom wardrobes, drawers, and shelves	9	\N	\N	[]	0.00	2026-09-12 06:58:50.965048	2026-09-12 06:58:50.965049
5e568882-ba0f-48d2-b007-6eda2aaa3724	c568f0d1-866e-40f3-9142-6883cacc65ae	Bathroom and bedroom mirrors	10	\N	\N	[]	0.00	2026-09-12 06:58:50.965049	2026-09-12 06:58:50.96505
abc290c0-1f29-46c3-837c-e70dd6fbc250	c568f0d1-866e-40f3-9142-6883cacc65ae	Bathroom soap holder, toilet paper holder, and robe/towel holders	11	\N	\N	[]	0.00	2026-09-12 06:58:50.965051	2026-09-12 06:58:50.965052
e3388372-8676-4d7c-976a-9e1406e0f5b9	c568f0d1-866e-40f3-9142-6883cacc65ae	Toilet (bowl, cistern, and flushing mechanism) (note any defects/leaks)	12	\N	\N	[]	0.00	2026-09-12 06:58:50.965053	2026-09-12 06:58:50.965054
bfa1c24a-18da-4504-ae14-ba08f3db0570	9ac832f1-403b-4646-91e4-07910ab5d335	Doors, windows, glass, handles, hinges, and locks	0	\N	\N	[]	0.00	2026-09-12 06:58:50.978545	2026-09-12 06:58:50.978548
e9ab2cec-9728-4199-afb1-9296bc0f0c79	9ac832f1-403b-4646-91e4-07910ab5d335	Floor finishes (tiles/terrazzo)	1	\N	\N	[]	0.00	2026-09-12 06:58:50.978548	2026-09-12 06:58:50.978549
f37bed3a-fdab-4ebf-ba12-a4e44577975a	9ac832f1-403b-4646-91e4-07910ab5d335	Walls and paint finish	2	\N	\N	[]	0.00	2026-09-12 06:58:50.978549	2026-09-12 06:58:50.97855
4722f54a-b155-4a19-81ea-fa99eb16ebd8	9ac832f1-403b-4646-91e4-07910ab5d335	Door locks and keys issued (list keys)	3	\N	\N	[]	0.00	2026-09-12 06:58:50.97855	2026-09-12 06:58:50.97855
e369329c-4757-48e1-b0af-f6df5b1e2625	9ac832f1-403b-4646-91e4-07910ab5d335	Electricity switches, sockets, and light fittings	4	\N	\N	[]	0.00	2026-09-12 06:58:50.978551	2026-09-12 06:58:50.978551
03cfc101-6322-4273-8b05-d20cf85648bc	9ac832f1-403b-4646-91e4-07910ab5d335	Water taps and plumbing visible fittings (note any defects/leaks)	5	\N	\N	[]	0.00	2026-09-12 06:58:50.978552	2026-09-12 06:58:50.978552
e30b8c25-8db0-4530-a4da-d24db81ed33d	9ac832f1-403b-4646-91e4-07910ab5d335	Hot water heater / shower	6	\N	\N	[]	0.00	2026-09-12 06:58:50.978553	2026-09-12 06:58:50.978553
e9ca40f4-ac66-4d4b-ae19-39dcfc376a49	9ac832f1-403b-4646-91e4-07910ab5d335	Sinks and drain points (note any defects/leaks)	7	\N	\N	[]	0.00	2026-09-12 06:58:50.978553	2026-09-12 06:58:50.978554
0796e3fb-c1b6-4491-ab72-335a1892971d	9ac832f1-403b-4646-91e4-07910ab5d335	Kitchen cabinets/cupboards, drawers, and shelves	8	\N	\N	[]	0.00	2026-09-12 06:58:50.978554	2026-09-12 06:58:50.978555
99836dfe-0f0c-46ca-8bd6-60a4398360bb	9ac832f1-403b-4646-91e4-07910ab5d335	Bedroom wardrobes, drawers, and shelves	9	\N	\N	[]	0.00	2026-09-12 06:58:50.978555	2026-09-12 06:58:50.978555
fd511087-6da5-45fe-bf31-8100892e5862	9ac832f1-403b-4646-91e4-07910ab5d335	Bathroom and bedroom mirrors	10	\N	\N	[]	0.00	2026-09-12 06:58:50.978556	2026-09-12 06:58:50.978556
cf247295-1507-4b61-8d65-f1ea24b132d5	9ac832f1-403b-4646-91e4-07910ab5d335	Bathroom soap holder, toilet paper holder, and robe/towel holders	11	\N	\N	[]	0.00	2026-09-12 06:58:50.978557	2026-09-12 06:58:50.978557
9777a98f-6119-4d20-b513-5f2a480de8ae	9ac832f1-403b-4646-91e4-07910ab5d335	Toilet (bowl, cistern, and flushing mechanism) (note any defects/leaks)	12	\N	\N	[]	0.00	2026-09-12 06:58:50.978557	2026-09-12 06:58:50.978558
26e691ca-1c32-4c3a-a7d2-9742495fa454	4220349f-1ceb-438a-aeee-34efa3feff04	Doors, windows, glass, handles, hinges, and locks	0	\N	\N	[]	0.00	2026-09-12 06:58:50.998207	2026-09-12 06:58:50.998212
84da6194-789e-46c9-b72c-8dc387b40ac9	4220349f-1ceb-438a-aeee-34efa3feff04	Floor finishes (tiles/terrazzo)	1	\N	\N	[]	0.00	2026-09-12 06:58:50.998213	2026-09-12 06:58:50.998214
9f2354d3-80b2-4432-b9fb-932f161133c9	4220349f-1ceb-438a-aeee-34efa3feff04	Walls and paint finish	2	\N	\N	[]	0.00	2026-09-12 06:58:50.998214	2026-09-12 06:58:50.998215
a5dbd5f4-d700-4f5c-83c3-20e48d03700a	4220349f-1ceb-438a-aeee-34efa3feff04	Door locks and keys issued (list keys)	3	\N	\N	[]	0.00	2026-09-12 06:58:50.998216	2026-09-12 06:58:50.998217
6eca9482-c22d-48db-b742-5061b7e80e15	4220349f-1ceb-438a-aeee-34efa3feff04	Electricity switches, sockets, and light fittings	4	\N	\N	[]	0.00	2026-09-12 06:58:50.998218	2026-09-12 06:58:50.998218
3f8d0360-4369-45b4-8e25-a47994b2559b	4220349f-1ceb-438a-aeee-34efa3feff04	Water taps and plumbing visible fittings (note any defects/leaks)	5	\N	\N	[]	0.00	2026-09-12 06:58:50.998219	2026-09-12 06:58:50.99822
a15c6294-afc8-4ddb-bc16-9dea95770682	4220349f-1ceb-438a-aeee-34efa3feff04	Hot water heater / shower	6	\N	\N	[]	0.00	2026-09-12 06:58:50.998221	2026-09-12 06:58:50.998221
a84169a6-4f3f-44c5-909f-dbb49c491e41	4220349f-1ceb-438a-aeee-34efa3feff04	Sinks and drain points (note any defects/leaks)	7	\N	\N	[]	0.00	2026-09-12 06:58:50.998221	2026-09-12 06:58:50.998222
105f669c-41a3-464d-82e2-ffb1b8f0286e	4220349f-1ceb-438a-aeee-34efa3feff04	Kitchen cabinets/cupboards, drawers, and shelves	8	\N	\N	[]	0.00	2026-09-12 06:58:50.998222	2026-09-12 06:58:50.998223
480e1ab2-ef1c-44c8-94f7-e11e59ee48bd	4220349f-1ceb-438a-aeee-34efa3feff04	Bedroom wardrobes, drawers, and shelves	9	\N	\N	[]	0.00	2026-09-12 06:58:50.998223	2026-09-12 06:58:50.998223
09871ff8-2766-4651-9f50-2def6eb38825	4220349f-1ceb-438a-aeee-34efa3feff04	Bathroom and bedroom mirrors	10	\N	\N	[]	0.00	2026-09-12 06:58:50.998224	2026-09-12 06:58:50.998225
6d088ed1-ef48-43e6-aeca-a7578661db2d	4220349f-1ceb-438a-aeee-34efa3feff04	Bathroom soap holder, toilet paper holder, and robe/towel holders	11	\N	\N	[]	0.00	2026-09-12 06:58:50.998225	2026-09-12 06:58:50.998225
39178c94-42ed-4bb1-add7-f6c922b03a75	4220349f-1ceb-438a-aeee-34efa3feff04	Toilet (bowl, cistern, and flushing mechanism) (note any defects/leaks)	12	\N	\N	[]	0.00	2026-09-12 06:58:50.998226	2026-09-12 06:58:50.998227
\.


--
-- Data for Name: inspection_notes; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.inspection_notes (id, inspection_id, user_id, note, created_at) FROM stdin;
\.


--
-- Data for Name: lease_inspections; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.lease_inspections (id, lease_id, inspection_type, inspection_date, inspector_user_id, tenant_signature_data, tenant_signed_name, tenant_signed_at, status, total_deduction_amount, created_at, updated_at, deposit_held, deposit_refunded, deposit_shortfall) FROM stdin;
ab178146-f8c7-4fe0-a583-dcbba36160c5	7e4b71ac-4c99-4031-8066-4ae95ba6fa51	move_in	\N	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	\N	\N	\N	draft	0.00	2026-09-12 06:58:50.879878	2026-09-12 06:58:50.879886	\N	\N	\N
0a739530-6795-480d-baff-f57505ec7efa	df06ed36-4ac4-4ff1-ad7e-fef330fa7753	move_in	\N	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	\N	\N	\N	draft	0.00	2026-09-12 06:58:50.937819	2026-09-12 06:58:50.937825	\N	\N	\N
c568f0d1-866e-40f3-9142-6883cacc65ae	04f7d786-d008-4578-9d0c-f1d672663846	move_in	\N	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	\N	\N	\N	draft	0.00	2026-09-12 06:58:50.959595	2026-09-12 06:58:50.959598	\N	\N	\N
9ac832f1-403b-4646-91e4-07910ab5d335	25afd600-2d2d-4b34-9869-ed60fc0f5a36	move_in	\N	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	\N	\N	\N	draft	0.00	2026-09-12 06:58:50.974481	2026-09-12 06:58:50.974484	\N	\N	\N
4220349f-1ceb-438a-aeee-34efa3feff04	443b9454-4c42-4d54-a9d0-2a0fffe546a9	move_in	\N	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	\N	\N	\N	draft	0.00	2026-09-12 06:58:50.990645	2026-09-12 06:58:50.990649	\N	\N	\N
\.


--
-- Data for Name: leases; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.leases (id, organization_id, unit_id, tenant_id, start_date, end_date, rent_amount, deposit_amount, billing_day, status, created_at, move_in_date, signed_on_behalf_of, signed_lease_urls, custom_fields) FROM stdin;
7e4b71ac-4c99-4031-8066-4ae95ba6fa51	20ff8602-5693-4418-a2cc-69001487f42c	d4f3c642-af04-412b-a402-2311501b98b4	d5def830-fb1f-4853-a0be-c0ef0c53736c	2026-09-01	2027-08-31	12000.00	12000.00	1	active	2026-09-12 06:58:50.81808	2026-09-01	\N	[]	[]
df06ed36-4ac4-4ff1-ad7e-fef330fa7753	20ff8602-5693-4418-a2cc-69001487f42c	dc5836a9-ea7a-485d-8bd1-43a0ec10b6ad	e4646cdf-6207-4880-a791-b80d09f08f9a	2026-09-01	2027-08-31	15000.00	15000.00	1	active	2026-09-12 06:58:50.916476	2026-09-01	\N	[]	[]
04f7d786-d008-4578-9d0c-f1d672663846	20ff8602-5693-4418-a2cc-69001487f42c	f4f74566-5186-4cdf-9efe-ee397099f73f	18281ab0-d1df-4943-8ed4-cee538489de8	2026-09-01	2027-08-31	18000.00	18000.00	1	active	2026-09-12 06:58:50.949282	2026-09-01	\N	[]	[]
25afd600-2d2d-4b34-9869-ed60fc0f5a36	20ff8602-5693-4418-a2cc-69001487f42c	50bf0619-780c-488c-a1f1-82076f05b10d	12fa5733-c9df-43d4-a2d2-ab55c4d7f7d5	2026-09-01	2027-08-31	20000.00	20000.00	1	active	2026-09-12 06:58:50.968747	2026-09-01	\N	[]	[]
443b9454-4c42-4d54-a9d0-2a0fffe546a9	20ff8602-5693-4418-a2cc-69001487f42c	49dfc34a-2792-43c7-b938-24d603171672	136c000c-f817-45c6-a4e9-e7bdc95f424b	2026-09-01	2027-08-31	10000.00	10000.00	1	active	2026-09-12 06:58:50.981885	2026-09-01	\N	[]	[]
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.messages (id, organization_id, phone_number, direction, message_type, content, template_name, status, provider_message_id, error_message, channel, triggered_by_user_id, tenant_id, created_at, updated_at, ticket_id) FROM stdin;
27392ed1-d4eb-40b9-9065-c99c932eab0d	20ff8602-5693-4418-a2cc-69001487f42c	254700000001	outgoing	notification	Hi Grace Mwangi, your rent of KES 12,000 is due on 01 Sep 2026. Please ensure payment is made on time. Thank you.	rent_due_reminder	failed	\N	WhatsApp API error: Authentication Error	whatsapp	\N	d5def830-fb1f-4853-a0be-c0ef0c53736c	2026-09-12 07:00:23.316349	2026-09-12 07:00:24.342541	\N
c1bda5c7-afba-4f2f-9640-ef0032719b27	20ff8602-5693-4418-a2cc-69001487f42c	254700000002	outgoing	notification	Hi David Kimani, your rent of KES 15,000 is due on 01 Sep 2026. Please ensure payment is made on time. Thank you.	rent_due_reminder	failed	\N	WhatsApp API error: Authentication Error	whatsapp	\N	e4646cdf-6207-4880-a791-b80d09f08f9a	2026-09-12 07:00:24.368237	2026-09-12 07:00:24.696511	\N
c247005b-fc44-45c5-b85f-f44b2b35ece4	20ff8602-5693-4418-a2cc-69001487f42c	254700000003	outgoing	notification	Hi Sarah Wanjiku, your rent of KES 18,000 is due on 01 Sep 2026. Please ensure payment is made on time. Thank you.	rent_due_reminder	failed	\N	WhatsApp API error: Authentication Error	whatsapp	\N	18281ab0-d1df-4943-8ed4-cee538489de8	2026-09-12 07:00:24.743302	2026-09-12 07:00:25.523819	\N
1d07dbba-7dce-49c8-b0fc-da2a878e6844	20ff8602-5693-4418-a2cc-69001487f42c	254700000004	outgoing	notification	Hi Peter Otieno, your rent of KES 20,000 is due on 01 Sep 2026. Please ensure payment is made on time. Thank you.	rent_due_reminder	failed	\N	WhatsApp API error: Authentication Error	whatsapp	\N	12fa5733-c9df-43d4-a2d2-ab55c4d7f7d5	2026-09-12 07:00:25.554553	2026-09-12 07:00:26.309788	\N
8aee2198-a692-4965-9332-e7836d425732	20ff8602-5693-4418-a2cc-69001487f42c	254700000005	outgoing	notification	Hi Mary Achieng, your rent of KES 10,000 is due on 01 Sep 2026. Please ensure payment is made on time. Thank you.	rent_due_reminder	failed	\N	WhatsApp API error: Authentication Error	whatsapp	\N	136c000c-f817-45c6-a4e9-e7bdc95f424b	2026-09-12 07:00:26.362062	2026-09-12 07:00:26.694723	\N
6f1da763-b130-413a-be68-3ab2baabe796	20ff8602-5693-4418-a2cc-69001487f42c	+254700000001	incoming	ticket	UI7BD6170U Confirmed. Ksh12,000.00 sent to RIVERSIDE PROPERTY for account 0100316372900 on 12/09/26 at 10:30 AM. New M-PESA balance is Ksh500.00. Transaction cost, Ksh0.00.	\N	received	demo_wamid_UI7BD6170U	\N	whatsapp	\N	d5def830-fb1f-4853-a0be-c0ef0c53736c	2026-09-12 08:03:40.049848	2026-09-12 08:03:40.049854	\N
02a0afb1-c7c1-4575-92ff-057bc52181e6	20ff8602-5693-4418-a2cc-69001487f42c	+254700000002	incoming	ticket	UI7FK5VY2Z Confirmed. Ksh30,000.00 sent to RIVERSIDE PROPERTY for account 0100316372900 on 12/09/26 at 10:30 AM. New M-PESA balance is Ksh500.00. Transaction cost, Ksh0.00.	\N	received	demo_wamid_UI7FK5VY2Z	\N	whatsapp	\N	e4646cdf-6207-4880-a791-b80d09f08f9a	2026-09-12 08:03:40.065978	2026-09-12 08:03:40.065988	\N
dd491422-0f3f-41f0-aab1-4fae68a2b27a	20ff8602-5693-4418-a2cc-69001487f42c	+254700000003	incoming	ticket	UI6QI57NHU Confirmed. Ksh25,000.00 sent to RIVERSIDE PROPERTY for account 0100316372900 on 12/09/26 at 10:30 AM. New M-PESA balance is Ksh500.00. Transaction cost, Ksh0.00.	\N	received	demo_wamid_UI6QI57NHU	\N	whatsapp	\N	18281ab0-d1df-4943-8ed4-cee538489de8	2026-09-12 08:03:40.087637	2026-09-12 08:03:40.087643	\N
f4b2e5a9-2721-4b9a-b730-32ce036de54c	20ff8602-5693-4418-a2cc-69001487f42c	+254700000004	incoming	ticket	UPTR5Q7VNK Confirmed. Ksh12,000.00 sent to RIVERSIDE PROPERTY for account 0100316372900 on 12/09/26 at 10:30 AM. New M-PESA balance is Ksh500.00. Transaction cost, Ksh0.00.	\N	received	demo_wamid_UPTR5Q7VNK	\N	whatsapp	\N	12fa5733-c9df-43d4-a2d2-ab55c4d7f7d5	2026-09-12 08:03:40.107211	2026-09-12 08:03:40.107217	\N
e40fc008-b9bd-4c54-b272-0b8da718a0aa	20ff8602-5693-4418-a2cc-69001487f42c	+254700000005	incoming	ticket	UMAC2R6HGB Confirmed. Ksh10,000.00 sent to RIVERSIDE PROPERTY for account 0100316372900 on 12/09/26 at 10:30 AM. New M-PESA balance is Ksh500.00. Transaction cost, Ksh0.00.	\N	received	demo_wamid_UMAC2R6HGB	\N	whatsapp	\N	136c000c-f817-45c6-a4e9-e7bdc95f424b	2026-09-12 08:03:40.120496	2026-09-12 08:03:40.120501	\N
cbdb4728-43dd-4149-9b5b-710bbc701a13	20ff8602-5693-4418-a2cc-69001487f42c	254700000001	outgoing	notification	Payment received ✔\n\nHi Grace Mwangi, we've received your payment of KES 12,000 on 21 Aug 2026. Thank you!	payment_receipt	failed	\N	WhatsApp API error: Authentication Error	whatsapp	\N	d5def830-fb1f-4853-a0be-c0ef0c53736c	2026-09-12 08:10:13.272548	2026-09-12 08:10:21.835345	\N
a2479c26-3cbe-4099-9f26-3b7c095c5dbf	20ff8602-5693-4418-a2cc-69001487f42c	254700000002	outgoing	notification	Payment received ✔\n\nHi David Kimani, we've received your payment of KES 15,000 on 21 Aug 2026. Thank you!	payment_receipt	failed	\N	WhatsApp API error: Authentication Error	whatsapp	\N	e4646cdf-6207-4880-a791-b80d09f08f9a	2026-09-12 08:10:21.860858	2026-09-12 08:10:23.125508	\N
7937f8b7-1045-48e7-9eb6-8a00e2cd0ec6	20ff8602-5693-4418-a2cc-69001487f42c	254700000003	outgoing	notification	Payment received ✔\n\nHi Sarah Wanjiku, we've received your payment of KES 18,000 on 21 Aug 2026. Thank you!	payment_receipt	failed	\N	WhatsApp API error: Authentication Error	whatsapp	\N	18281ab0-d1df-4943-8ed4-cee538489de8	2026-09-12 08:10:23.18506	2026-09-12 08:10:24.726769	\N
096782ef-37d6-43ac-88fb-ba0df348d3f1	20ff8602-5693-4418-a2cc-69001487f42c	254700000005	outgoing	notification	Payment received ✔\n\nHi Mary Achieng, we've received your payment of KES 10,000 on 21 Aug 2026. Thank you!	payment_receipt	failed	\N	WhatsApp API error: Authentication Error	whatsapp	\N	136c000c-f817-45c6-a4e9-e7bdc95f424b	2026-09-12 08:10:24.804817	2026-09-12 08:10:27.588211	\N
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.notification_preferences (id, organization_id, user_id, email_enabled, whatsapp_enabled, sms_enabled, in_app_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.notifications (id, organization_id, user_id, title, body, notification_type, is_read, created_at) FROM stdin;
\.


--
-- Data for Name: organization_invitations; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.organization_invitations (id, email, role_id, organization_id, token, status, created_at, phone) FROM stdin;
\.


--
-- Data for Name: organization_members; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.organization_members (id, user_id, organization_id, role_id, created_at) FROM stdin;
3b83c201-7ad7-4228-948a-115e58d0c9c2	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	20ff8602-5693-4418-a2cc-69001487f42c	c8d842c2-9248-4d56-958b-5ca5a54de1d7	2026-09-11 08:56:25.99008
f252bfd0-8103-4ad5-baeb-d951c0d120e8	66c8d44d-6b7d-4a59-b8f8-3b7526fd4853	20ff8602-5693-4418-a2cc-69001487f42c	c8d842c2-9248-4d56-958b-5ca5a54de1d7	2026-09-12 06:39:18.80438
cffbcb35-0173-4237-aed7-2cd91409c053	f4a4cc0f-93a7-4600-9ea7-2fd3496c2468	20ff8602-5693-4418-a2cc-69001487f42c	d1a5193a-8889-45f0-81b5-55b2399a883c	2026-09-12 08:23:19.223323
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.organizations (id, name, owner_id, created_at) FROM stdin;
20ff8602-5693-4418-a2cc-69001487f42c	Riverside Property Management	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	2026-09-11 08:56:25.986913
\.


--
-- Data for Name: otp_verifications; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.otp_verifications (id, user_id, purpose, phone, code_hash, expires_at, attempts, last_sent_at, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: password_history; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.password_history (id, user_id, password_hash, created_at) FROM stdin;
f672298b-b1eb-48c7-9950-c75683b16988	f4a4cc0f-93a7-4600-9ea7-2fd3496c2468	$2b$12$VDdZ.iOd5n5cHoT95TDusO7LaMpVYjinR03RhKKcOmAbAxWVGWYSS	2026-09-12 08:23:19.20653
\.


--
-- Data for Name: payment_review_items; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.payment_review_items (id, organization_id, amount, payment_date, reference, payer_phone, payer_name, raw_transaction, tenant_id, lease_id, status, flag_reason, notes, resolved_at, resolved_by_user_id, resolution_payment_id, rejection_reason, created_at, created_by_user_id, source, source_message_id, extracted_reference, extracted_amount, message_timestamp, payer_phone_hash) FROM stdin;
89b8d269-1529-4df4-8037-4326218d152a	20ff8602-5693-4418-a2cc-69001487f42c	12000.00	\N	UPTR5Q7VNK	+254700000004	Peter Otieno	UPTR5Q7VNK Confirmed. Ksh12,000.00 sent to RIVERSIDE PROPERTY for account 0100316372900 on 12/09/26 at 10:30 AM. New M-PESA balance is Ksh500.00. Transaction cost, Ksh0.00.	12fa5733-c9df-43d4-a2d2-ab55c4d7f7d5	25afd600-2d2d-4b34-9869-ed60fc0f5a36	pending_review	manual_flag	\N	\N	\N	\N	\N	2026-09-12 08:03:40.12317	\N	whatsapp	f4b2e5a9-2721-4b9a-b730-32ce036de54c	UPTR5Q7VNK	12000.00	2026-09-12 08:03:40.112517	0cd63ed39f061165c4b377485adf66309b7c4c034249b5e5c63045e2f3e39b76
d7f3d4f1-6cd7-4b18-bb56-564c72df4e0e	20ff8602-5693-4418-a2cc-69001487f42c	12000.00	\N	UI7BD6170U	+254700000001	Grace Mwangi	UI7BD6170U Confirmed. Ksh12,000.00 sent to RIVERSIDE PROPERTY for account 0100316372900 on 12/09/26 at 10:30 AM. New M-PESA balance is Ksh500.00. Transaction cost, Ksh0.00.	d5def830-fb1f-4853-a0be-c0ef0c53736c	7e4b71ac-4c99-4031-8066-4ae95ba6fa51	applied	manual_flag	\N	2026-09-12 08:10:13.066868	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	339a0b0c-a4f3-4cd6-b22c-2270593f35f7	\N	2026-09-12 08:03:40.070635	\N	whatsapp	6f1da763-b130-413a-be68-3ab2baabe796	UI7BD6170U	12000.00	2026-09-12 08:03:40.055053	0e0b94b80e4f9e9cf41045d4392444251ad8eb8dd891aad12a10938dc1b64445
3d393240-f6e4-4e0e-aa8a-28ed3c6cd231	20ff8602-5693-4418-a2cc-69001487f42c	30000.00	\N	UI7FK5VY2Z	+254700000002	David Kimani	UI7FK5VY2Z Confirmed. Ksh30,000.00 sent to RIVERSIDE PROPERTY for account 0100316372900 on 12/09/26 at 10:30 AM. New M-PESA balance is Ksh500.00. Transaction cost, Ksh0.00.	e4646cdf-6207-4880-a791-b80d09f08f9a	df06ed36-4ac4-4ff1-ad7e-fef330fa7753	applied	manual_flag	\N	2026-09-12 08:10:13.12374	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	56ec1c5d-719d-4228-86e6-fd56e97f6da8	\N	2026-09-12 08:03:40.089989	\N	whatsapp	02a0afb1-c7c1-4575-92ff-057bc52181e6	UI7FK5VY2Z	30000.00	2026-09-12 08:03:40.07523	c4b6fe28034a3e7f8409b7ed28ea72356240ca9943deb532a6040fc6a221f71a
002df80c-5b70-4fb7-b1ba-6ae90c67702c	20ff8602-5693-4418-a2cc-69001487f42c	25000.00	\N	UI6QI57NHU	+254700000003	Sarah Wanjiku	UI6QI57NHU Confirmed. Ksh25,000.00 sent to RIVERSIDE PROPERTY for account 0100316372900 on 12/09/26 at 10:30 AM. New M-PESA balance is Ksh500.00. Transaction cost, Ksh0.00.	18281ab0-d1df-4943-8ed4-cee538489de8	04f7d786-d008-4578-9d0c-f1d672663846	applied	manual_flag	\N	2026-09-12 08:10:13.141661	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	f713c474-8a9e-40b9-903e-8b2407c3bc90	\N	2026-09-12 08:03:40.109495	\N	whatsapp	dd491422-0f3f-41f0-aab1-4fae68a2b27a	UI6QI57NHU	25000.00	2026-09-12 08:03:40.097911	b754ad56300a47b1e2958d8e3042624143c904ac42892c370b278e1eb34c9c26
1b5ba6c7-8f76-4100-91e7-c85b22961931	20ff8602-5693-4418-a2cc-69001487f42c	10000.00	\N	UMAC2R6HGB	+254700000005	Mary Achieng	UMAC2R6HGB Confirmed. Ksh10,000.00 sent to RIVERSIDE PROPERTY for account 0100316372900 on 12/09/26 at 10:30 AM. New M-PESA balance is Ksh500.00. Transaction cost, Ksh0.00.	136c000c-f817-45c6-a4e9-e7bdc95f424b	443b9454-4c42-4d54-a9d0-2a0fffe546a9	applied	manual_flag	\N	2026-09-12 08:10:13.157512	07c8ef3f-6770-4f4a-b05f-32f3108a68c2	7f29781d-8441-44b8-b870-53e6ac3fb503	\N	2026-09-12 08:03:40.131304	\N	whatsapp	e40fc008-b9bd-4c54-b272-0b8da718a0aa	UMAC2R6HGB	10000.00	2026-09-12 08:03:40.130545	eb678d8b6a8e93ae7cf18d94f86bc4e38d2c837cb5ae673c7c0db056b4d270b5
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.payments (id, organization_id, tenant_id, lease_id, amount, payment_method, reference, payment_date, created_at, payment_type) FROM stdin;
f2ce1b02-261d-421d-be19-5c12b807394d	20ff8602-5693-4418-a2cc-69001487f42c	136c000c-f817-45c6-a4e9-e7bdc95f424b	443b9454-4c42-4d54-a9d0-2a0fffe546a9	10000.00	cash	PRIORDPST01	2026-08-13	2026-09-12 08:03:39.929295	deposit
339a0b0c-a4f3-4cd6-b22c-2270593f35f7	20ff8602-5693-4418-a2cc-69001487f42c	d5def830-fb1f-4853-a0be-c0ef0c53736c	7e4b71ac-4c99-4031-8066-4ae95ba6fa51	12000.00	mpesa	UI7BD6170U	2026-08-21	2026-09-12 08:10:13.056919	deposit
56ec1c5d-719d-4228-86e6-fd56e97f6da8	20ff8602-5693-4418-a2cc-69001487f42c	e4646cdf-6207-4880-a791-b80d09f08f9a	df06ed36-4ac4-4ff1-ad7e-fef330fa7753	15000.00	mpesa	UI7FK5VY2Z	2026-08-21	2026-09-12 08:10:13.105128	deposit
7f333d29-6d88-45ca-8011-89fed12006b3	20ff8602-5693-4418-a2cc-69001487f42c	e4646cdf-6207-4880-a791-b80d09f08f9a	df06ed36-4ac4-4ff1-ad7e-fef330fa7753	15000.00	mpesa	UI7FK5VY2Z	2026-08-21	2026-09-12 08:10:13.12072	rent
f713c474-8a9e-40b9-903e-8b2407c3bc90	20ff8602-5693-4418-a2cc-69001487f42c	18281ab0-d1df-4943-8ed4-cee538489de8	04f7d786-d008-4578-9d0c-f1d672663846	18000.00	mpesa	UI6QI57NHU	2026-08-21	2026-09-12 08:10:13.133363	deposit
396af59c-b59a-4e51-8ac1-5a9d160f8526	20ff8602-5693-4418-a2cc-69001487f42c	18281ab0-d1df-4943-8ed4-cee538489de8	04f7d786-d008-4578-9d0c-f1d672663846	7000.00	mpesa	UI6QI57NHU	2026-08-21	2026-09-12 08:10:13.138555	rent
7f29781d-8441-44b8-b870-53e6ac3fb503	20ff8602-5693-4418-a2cc-69001487f42c	136c000c-f817-45c6-a4e9-e7bdc95f424b	443b9454-4c42-4d54-a9d0-2a0fffe546a9	10000.00	mpesa	UMAC2R6HGB	2026-08-21	2026-09-12 08:10:13.152196	rent
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.properties (id, name, address, city, country, organization_id, created_at) FROM stdin;
0d4dae1c-05dc-4bdf-8731-cc09caabdc0a	Riverside Apartments	00100-177	nairobi	Kenya	20ff8602-5693-4418-a2cc-69001487f42c	2026-09-12 06:50:37.004502
\.


--
-- Data for Name: property_finance_managers; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.property_finance_managers (id, property_id, user_id) FROM stdin;
\.


--
-- Data for Name: property_managers; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.property_managers (id, property_id, user_id) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.roles (id, name, created_at) FROM stdin;
c8d842c2-9248-4d56-958b-5ca5a54de1d7	LANDLORD	2026-07-18 06:41:46.030025
a0689163-1b94-4d9f-917b-d2c90a8ffd59	PROPERTY_MANAGER	2026-07-18 06:41:46.030039
2f6ff036-802c-4b49-b5d2-6be5a69d85bf	FINANCE	2026-07-18 06:41:46.030051
d1a5193a-8889-45f0-81b5-55b2399a883c	TENANT	2026-07-18 06:41:46.030066
98e77e5b-65fc-4323-8158-9a0111142673	SYSTEM	2026-07-18 06:41:46.030075
\.


--
-- Data for Name: tenant_documents; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.tenant_documents (id, tenant_id, document_type, file_url, original_filename, uploaded_by_user_id, uploaded_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.tenants (id, organization_id, full_name, email, phone, id_number, emergency_contact, created_at, alternative_phone, next_of_kin_name, next_of_kin_relationship, next_of_kin_phone, next_of_kin_alt_phone, next_of_kin_email, employer_name, employer_location, employer_phone, employer_email, user_id, phone_hash, alternative_phone_hash, email_hash, id_number_hash) FROM stdin;
d5def830-fb1f-4853-a0be-c0ef0c53736c	20ff8602-5693-4418-a2cc-69001487f42c	Grace Mwangi	gAAAAABqpPgqOQyfRBUZannBi54qjA1MUgmOlhXDyAkquuvaPAEBYeX6Fzw3JmBmbH91wk0pYBmTnY5UKlRpx0ARljJ2vVtZzg3l3N2SLqua44jVS6PE0ag=	gAAAAABqpPgq45xOULuHY4tQslHpjgJe9OwhDPHpEdlDKTvQ-efBoy2k1o40dPsE4dM64ydn3uIdy5ZUVmuZX59ezQ-h_AGZwQ==	gAAAAABqpPgqAGxs4ma9cmjTDv15XWv1_JTr7xoFcu4xjeFF07x_hUrz3sWtP336qHoJE5OF23OCGjZd5atRgKGFJYeCjigTdQ==	gAAAAABqpPgqfuJiwmkozy6mwbPszItboms4FCptBteFevej9Cj2VDIwUUDyu7c1yhZ0XqhEq_77c3_oUG5PND1IbXGjs-CQzaSRDbNQ2EcJh_z7Z0gO3Fd6trnIe4fiLvPcUjtXEeJ0	2026-09-12 06:58:50.771309	gAAAAABqpPgqwxFQ2FjdJw24u7KhFTqrz8BWW4QmWnRpMZ8Cs2BO5c408D3IdhPIblvV5LwiJopUx0LIvMccyf01dS6rNxHhQw==	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7f56bce6216d51956608a2fdb6d7b2c7cd6475579e70bdb27c09cc987c5c5c21	fbdb325f3c2a89b7cdec3c9165a2a3cf3147b516c9e0fbe41e322d7ea11e9149	7c3a2c6d462af965ccfc813d5754f0c9c41e8d59867a751935c1922d9646fab8	265aba5a6e5a922743e8fe90df1b5e616a7d1e1f158c5e77f6812f735242f182
e4646cdf-6207-4880-a791-b80d09f08f9a	20ff8602-5693-4418-a2cc-69001487f42c	David Kimani	gAAAAABqpPgqU0fXr0VRSVD4KI3S8ia_HNTYmwtoJQygn11pl2_4qOy7LY_SfeEY7jfKuGBhFV19HBDYJCfdLR9ynrq-2x1PyAKnUJU9Qq9Gyna9xYcgieo=	gAAAAABqpPgq7qdmIiobkTD_XDzJ-tWX7adaEzzluR9G85SWkmCmNlp0cb_mrvYNcdLjyPmJgrXtIwyQTdcAhFIEo7gwXMtWRw==	gAAAAABqpPgqbKGNNZFiMk-PiuUJl-bDpZDUhxaQhq2YZItHuKqBMzx1DrYfd6lFC0cIeeHzpjxMtJTaBq0NhDvTpQ8YmmaKZw==	gAAAAABqpPgqX_3uLF5dwJKRbf88VXWakhjANNCkoeminwFrBgUesA4byjLNJsmGp-u4HOoFyyfApwU9A-cAoZsbXNUp5OxbQBHjeygkjBQZqFjBkN-wP65hTw-aL5sGTcbvsuxxs6wd	2026-09-12 06:58:50.912744	gAAAAABqpPgq45hIAi6rHMxE4Xhbz6lGMrAlEtYcnsvxGqZV2wf1FxyBBP9frz0i3hGJ3ds2t88PE2R6A3J1P3LFP7YStguA7A==	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	c7fc1528667d87f464c7b9302f64bef96b147870114cba3e3aa0b7de8fb8daa1	c1907bbec0c8b13d93e9113ce7832e9430f9eb34b73b52433f8d4616b76bdbf2	13c3ee5f8d6477f95adbfac5b82eef0b1b3dd4e90370d53b05d226c9b2d63a0d	ab5252938a55ddde23dc9e20898f67bb13be93626de0c09d4ee85b61147c906f
18281ab0-d1df-4943-8ed4-cee538489de8	20ff8602-5693-4418-a2cc-69001487f42c	Sarah Wanjiku	gAAAAABqpPgqjPIw62Q1OJrUV1axV1zr-Mnp3sd6OsFMkRqPuLmD-2tdjcEefzUfQPDyhG09dOwhAIuD5OHeMMAaf-Lq_qwNkjFOd2t0DqsPYrxxuubyLcM=	gAAAAABqpPgqc2CdImllKhPVuJw26kGBk9avABg33wIcrcxFTYbQ26vh_t8Ia3GIF5sn3D7cD1K5lBj5ST2g1WWfrb1kUZD9kg==	gAAAAABqpPgq2tgaiYQxESUrPyjjjzjlzZvmjJnAHu3E6MX3CCUiyviR1UXtSo-7U_ecMOJmP7vSQeSoyokI6pSEpWeU49eJAg==	gAAAAABqpPgqy3WoLR-aLvgAYAxFTR8CAJtRPBbepdPi6uR4SInd1H8ZXCNmjtvkPgXmzRvVM-8QnN7TPp0lgQJIyq7nyeDKVDDPH0AW03C7HOEdraYFQ6CfV-AptnaQJQOWwT-xL9Ra	2026-09-12 06:58:50.947042	gAAAAABqpPgqBZsGoD1ePsWQwe-ddjyj7_eYQea5dhX81XgZtdqNGPMYV2sOJuwuYHPOC8dQ8UGDUpgsCnm-oLMhuRX1CYjGHA==	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	678bd3c810fadb631a2de2292514a17b94432353d8e7dad3d317e7e8bddac9d4	e56efab63de1d973f5a4efc0603f4fd6faf6970c14865a74f365e835081e3da0	a27f63286deab81b2e446f87c3486871b8a0f5fd8423637cdfd649d17b278a08	aa48b85fe7ce35d1752c3176326cfa9a2301f195c5138642b57dd28df7bc17e2
12fa5733-c9df-43d4-a2d2-ab55c4d7f7d5	20ff8602-5693-4418-a2cc-69001487f42c	Peter Otieno	gAAAAABqpPgqgXhwUyT3KpmYzvqBBWktaE0U-sK2AN3VSzAhAeMSIVf2HVrWWrf7bPkSkpJ_Dga9ZEdijQbku9reoowOaA6t7a65zTyO40iR-CuKGcoHSyo=	gAAAAABqpPgqtr_oZfAT2vDbK7MGa_j-5XrWYEp9ImugK_Epj3x4s79KkvwBHlmLBwRpwNC_JxNin7yeRxa3U2FzHEHKxJaXMw==	gAAAAABqpPgqPiScYawpvkMvLJL4XoxOv4OR_biljNVczmogIEGXmuPlK95w5bvquHSxHGF6uppn6mxmOc8PzW11dF6wimIhCg==	gAAAAABqpPgqGwQvfz0qY0gabvyvGSYABWl16I1YNsh0TxoSJ1eChO0CGUmvRoz-BrIWATN-ucnC5E13Z_bJ1PbD_Ne2nkfzFcebWhvCeJ_O5ui1dV7v-mJYF2vd_F3cfk_8footZG38	2026-09-12 06:58:50.967662	gAAAAABqpPgqTQ4RPUHzQywFNb4luvh7btHR3xuT-3i3qbuTXlL5OTw065suab_qJcMe4Un4mgp7a_6co9ToyGj6Uh3ThqnBJQ==	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	bf9a39c96a4ddd3a839141f59ac79205d0148fa8b951eabd07ada589a91492c9	7567186f42ec4f67336fdc32ae009f15c264c2cd24d25d48ff7464cd11202a85	afeb942d0ae440567abcd23a5fb07c4a1002cb2e263e0f709429f72f703df126	e42f75bb788f2295f32dce173a07184215facf46cea356c14afabdb48810f748
136c000c-f817-45c6-a4e9-e7bdc95f424b	20ff8602-5693-4418-a2cc-69001487f42c	Mary Achieng	gAAAAABqpPgqdys2D0aYvqxaR0-Knpx3ESSxmzdWHF7coO7IykVDxfO5FpXaIU1I384mIdZefEC1S9TNUuvARTFKK1rxQN_v9g==	gAAAAABqpPgqMngsNEOPtZ3qLVT65lZS-rHX3hjsONu6YGFm409J9iaCRepqBMHRFpTUZwhxeeHuMNleongJwjpxGM6jJLnyvg==	gAAAAABqpPgql8cPkoARJaWr-IWTn7luRPwsqsDhoeSzOjU945WrygCEd9ggO-3y53yaCUKnxROyNEmy54jfZofwccWEZyWFnA==	gAAAAABqpPgqug3pu-oGpMsRpCPjSkMidJWpXAP_iXEESI3A8DEv3VgJDRs13Ja7_Jyk5jk84YugAHQcZd6J5O-gWpayAjQZJKPnLODmp07o81MX69Auh7pnqOFmINdufXxUaOEA0v6g	2026-09-12 06:58:50.980726	gAAAAABqpPgqHReRTew5hy9iMLlnLaLBtZvARvyU0jsUjFDl_CKD3HG8qwoK94ezsxPT3DaV1zejPuwDqJbWOh7g2-DxyP3n3w==	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	cb55fd8e6b60c798c851e54a6bc369db59fc762a62b54d49820c0d9f1630a94c	91f8e8c30d03ee1726bb26769085687a1fc63009344978a462854cf1ea3cea32	dcf9188c15fd5481b8038b6c4bfe0c1bff5236c12eaf0d3735e8bbfcffb31432	b4790e6933140f2effe0fb29cbeadd610d4d720688739afa1eb75dff00f80d72
\.


--
-- Data for Name: ticket_assignments; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.ticket_assignments (id, ticket_id, assigned_from, assigned_to, reason, assigned_at) FROM stdin;
\.


--
-- Data for Name: ticket_attachments; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.ticket_attachments (id, ticket_id, uploaded_by, file_name, file_url, created_at) FROM stdin;
\.


--
-- Data for Name: ticket_messages; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.ticket_messages (id, ticket_id, sender_id, message, is_internal, created_at, recipient_id) FROM stdin;
\.


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.tickets (id, organization_id, tenant_id, source_phone, source_message_id, description, status, source, created_at, updated_at, property_id, unit_id, created_by, assigned_to, priority, category, opened_at, resolved_at, closed_at, title) FROM stdin;
\.


--
-- Data for Name: units; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.units (id, property_id, name, description, bedrooms, bathrooms, size_sqm, rent_amount, is_active, created_at) FROM stdin;
d4f3c642-af04-412b-a402-2311501b98b4	0d4dae1c-05dc-4bdf-8731-cc09caabdc0a	A1	1-bedroom	1	1	0	12000.00	t	2026-09-12 06:54:48.301203
dc5836a9-ea7a-485d-8bd1-43a0ec10b6ad	0d4dae1c-05dc-4bdf-8731-cc09caabdc0a	A2	1-bedroom	1	1	0	15000.00	t	2026-09-12 06:54:48.301208
f4f74566-5186-4cdf-9efe-ee397099f73f	0d4dae1c-05dc-4bdf-8731-cc09caabdc0a	A3	2-bedroom	2	1	0	18000.00	t	2026-09-12 06:54:48.301209
50bf0619-780c-488c-a1f1-82076f05b10d	0d4dae1c-05dc-4bdf-8731-cc09caabdc0a	A4	2-bedroom	2	1	0	20000.00	t	2026-09-12 06:54:48.30121
49dfc34a-2792-43c7-b938-24d603171672	0d4dae1c-05dc-4bdf-8731-cc09caabdc0a	A5	Bedsitter	0	1	0	10000.00	t	2026-09-12 06:54:48.301211
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.users (id, email, password_hash, is_active, refresh_token, reset_token, reset_token_expiry, role_id, full_name, phone, phone_verified, failed_login_count, locked_until) FROM stdin;
f4a4cc0f-93a7-4600-9ea7-2fd3496c2468	tenant@alphaone.africa	$2b$12$VDdZ.iOd5n5cHoT95TDusO7LaMpVYjinR03RhKKcOmAbAxWVGWYSS	t	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJmNGE0Y2MwZi05M2E3LTQ2MDAtOWVhNy0yZmQzNDk2YzI0NjgiLCJleHAiOjE3ODk4MDYyOTB9.h5WrEFTKIBRu4M4NCE2CleANKvFweo9OYrzPkKXHQ6s	\N	\N	d1a5193a-8889-45f0-81b5-55b2399a883c	Riverside Tenant	\N	t	0	\N
66c8d44d-6b7d-4a59-b8f8-3b7526fd4853	remingtonherman7@gmail.com	$2b$12$57yYPlCxo5mvN5gJ2PsHi.17hoYNzSuB8BdcRRxAVFYfgNFkkjHk.	t	\N	\N	\N	\N	Herman Remington	0725325915	t	0	\N
07c8ef3f-6770-4f4a-b05f-32f3108a68c2	demo@alphaone.africa	$2b$12$cCJtjhFupjsqPN9KkLAVpehpwvZ2lTyBf8.ETTiJOMWttanuttpwK	t	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwN2M4ZWYzZi02NzcwLTRmNGEtYjA1Zi0zMmYzMTA4YTY4YzIiLCJleHAiOjE3ODk4MDA0MTF9._CMvzhzFAhA9J6Pz420OlyrK-b_HVrVNjzXuVowl51M	\N	\N	c8d842c2-9248-4d56-958b-5ca5a54de1d7	Demo Landlord	+254700000000	t	0	\N
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.vendors (id, organization_id, vendor_name, contact_person, phone, email, kra_pin, address, notes, created_at) FROM stdin;
\.


--
-- Data for Name: whatsapp_integrations; Type: TABLE DATA; Schema: public; Owner: rental_user
--

COPY public.whatsapp_integrations (id, organization_id, meta_phone_number_id, meta_business_account_id, environment, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: charges charges_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.charges
    ADD CONSTRAINT charges_pkey PRIMARY KEY (id);


--
-- Name: checklist_item_templates checklist_item_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.checklist_item_templates
    ADD CONSTRAINT checklist_item_templates_pkey PRIMARY KEY (id);


--
-- Name: expense_attachments expense_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.expense_attachments
    ADD CONSTRAINT expense_attachments_pkey PRIMARY KEY (id);


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: inspection_items inspection_items_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.inspection_items
    ADD CONSTRAINT inspection_items_pkey PRIMARY KEY (id);


--
-- Name: inspection_notes inspection_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.inspection_notes
    ADD CONSTRAINT inspection_notes_pkey PRIMARY KEY (id);


--
-- Name: lease_inspections lease_inspections_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.lease_inspections
    ADD CONSTRAINT lease_inspections_pkey PRIMARY KEY (id);


--
-- Name: leases leases_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.leases
    ADD CONSTRAINT leases_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: organization_invitations organization_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_pkey PRIMARY KEY (id);


--
-- Name: organization_invitations organization_invitations_token_key; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_token_key UNIQUE (token);


--
-- Name: organization_members organization_members_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT organization_members_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: otp_verifications otp_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.otp_verifications
    ADD CONSTRAINT otp_verifications_pkey PRIMARY KEY (id);


--
-- Name: password_history password_history_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.password_history
    ADD CONSTRAINT password_history_pkey PRIMARY KEY (id);


--
-- Name: payment_review_items payment_review_items_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.payment_review_items
    ADD CONSTRAINT payment_review_items_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: property_finance_managers property_finance_managers_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.property_finance_managers
    ADD CONSTRAINT property_finance_managers_pkey PRIMARY KEY (id);


--
-- Name: property_managers property_managers_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.property_managers
    ADD CONSTRAINT property_managers_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: tenant_documents tenant_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.tenant_documents
    ADD CONSTRAINT tenant_documents_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: ticket_assignments ticket_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.ticket_assignments
    ADD CONSTRAINT ticket_assignments_pkey PRIMARY KEY (id);


--
-- Name: ticket_attachments ticket_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.ticket_attachments
    ADD CONSTRAINT ticket_attachments_pkey PRIMARY KEY (id);


--
-- Name: ticket_messages ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_integrations uniq_whatsapp_integrations_env_phone_number; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.whatsapp_integrations
    ADD CONSTRAINT uniq_whatsapp_integrations_env_phone_number UNIQUE (environment, meta_phone_number_id);


--
-- Name: units units_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_pkey PRIMARY KEY (id);


--
-- Name: expense_categories uq_expense_category_org_name; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT uq_expense_category_org_name UNIQUE (organization_id, name);


--
-- Name: notification_preferences uq_notification_preferences_user; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT uq_notification_preferences_user UNIQUE (user_id);


--
-- Name: property_finance_managers uq_property_finance_manager; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.property_finance_managers
    ADD CONSTRAINT uq_property_finance_manager UNIQUE (property_id, user_id);


--
-- Name: property_managers uq_property_manager; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.property_managers
    ADD CONSTRAINT uq_property_manager UNIQUE (property_id, user_id);


--
-- Name: organization_members uq_user_org; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT uq_user_org UNIQUE (user_id, organization_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_integrations whatsapp_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.whatsapp_integrations
    ADD CONSTRAINT whatsapp_integrations_pkey PRIMARY KEY (id);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_entity_type; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_audit_logs_entity_type ON public.audit_logs USING btree (entity_type);


--
-- Name: ix_audit_logs_org_created; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_audit_logs_org_created ON public.audit_logs USING btree (organization_id, created_at);


--
-- Name: ix_audit_logs_organization_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_audit_logs_organization_id ON public.audit_logs USING btree (organization_id);


--
-- Name: ix_charges_due_date; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_charges_due_date ON public.charges USING btree (due_date);


--
-- Name: ix_charges_lease_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_charges_lease_id ON public.charges USING btree (lease_id);


--
-- Name: ix_charges_org_due; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_charges_org_due ON public.charges USING btree (organization_id, due_date);


--
-- Name: ix_charges_organization_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_charges_organization_id ON public.charges USING btree (organization_id);


--
-- Name: ix_expenses_expense_date; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_expenses_expense_date ON public.expenses USING btree (expense_date);


--
-- Name: ix_expenses_organization_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_expenses_organization_id ON public.expenses USING btree (organization_id);


--
-- Name: ix_expenses_property_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_expenses_property_id ON public.expenses USING btree (property_id);


--
-- Name: ix_expenses_status; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_expenses_status ON public.expenses USING btree (status);


--
-- Name: ix_messages_phone_number; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_messages_phone_number ON public.messages USING btree (phone_number);


--
-- Name: ix_messages_provider_message_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_messages_provider_message_id ON public.messages USING btree (provider_message_id);


--
-- Name: ix_messages_ticket_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_messages_ticket_id ON public.messages USING btree (ticket_id);


--
-- Name: ix_notifications_is_read; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_notifications_is_read ON public.notifications USING btree (is_read);


--
-- Name: ix_notifications_organization_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_notifications_organization_id ON public.notifications USING btree (organization_id);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_organization_invitations_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_organization_invitations_id ON public.organization_invitations USING btree (id);


--
-- Name: ix_organization_members_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_organization_members_id ON public.organization_members USING btree (id);


--
-- Name: ix_otp_verifications_user_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_otp_verifications_user_id ON public.otp_verifications USING btree (user_id);


--
-- Name: ix_password_history_user_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_password_history_user_id ON public.password_history USING btree (user_id);


--
-- Name: ix_payment_review_items_org_status; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_payment_review_items_org_status ON public.payment_review_items USING btree (organization_id, status);


--
-- Name: ix_payment_review_items_payer_phone_hash; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_payment_review_items_payer_phone_hash ON public.payment_review_items USING btree (payer_phone_hash);


--
-- Name: ix_payment_review_items_source; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_payment_review_items_source ON public.payment_review_items USING btree (source);


--
-- Name: ix_payments_lease_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_payments_lease_id ON public.payments USING btree (lease_id);


--
-- Name: ix_payments_org_date; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_payments_org_date ON public.payments USING btree (organization_id, payment_date);


--
-- Name: ix_payments_organization_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_payments_organization_id ON public.payments USING btree (organization_id);


--
-- Name: ix_payments_payment_date; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_payments_payment_date ON public.payments USING btree (payment_date);


--
-- Name: ix_payments_tenant_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_payments_tenant_id ON public.payments USING btree (tenant_id);


--
-- Name: ix_properties_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_properties_id ON public.properties USING btree (id);


--
-- Name: ix_tenants_alternative_phone_hash; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_tenants_alternative_phone_hash ON public.tenants USING btree (alternative_phone_hash);


--
-- Name: ix_tenants_email_hash; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_tenants_email_hash ON public.tenants USING btree (email_hash);


--
-- Name: ix_tenants_id_number_hash; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_tenants_id_number_hash ON public.tenants USING btree (id_number_hash);


--
-- Name: ix_tenants_phone_hash; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_tenants_phone_hash ON public.tenants USING btree (phone_hash);


--
-- Name: ix_tenants_user_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_tenants_user_id ON public.tenants USING btree (user_id);


--
-- Name: ix_ticket_assignments_ticket_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_ticket_assignments_ticket_id ON public.ticket_assignments USING btree (ticket_id);


--
-- Name: ix_ticket_attachments_ticket_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_ticket_attachments_ticket_id ON public.ticket_attachments USING btree (ticket_id);


--
-- Name: ix_ticket_messages_recipient_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_ticket_messages_recipient_id ON public.ticket_messages USING btree (recipient_id);


--
-- Name: ix_ticket_messages_ticket_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_ticket_messages_ticket_id ON public.ticket_messages USING btree (ticket_id);


--
-- Name: ix_tickets_assigned_to; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_tickets_assigned_to ON public.tickets USING btree (assigned_to);


--
-- Name: ix_tickets_created_at; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_tickets_created_at ON public.tickets USING btree (created_at);


--
-- Name: ix_tickets_org_created; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_tickets_org_created ON public.tickets USING btree (organization_id, created_at);


--
-- Name: ix_tickets_organization_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_tickets_organization_id ON public.tickets USING btree (organization_id);


--
-- Name: ix_tickets_property_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_tickets_property_id ON public.tickets USING btree (property_id);


--
-- Name: ix_tickets_source_phone; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_tickets_source_phone ON public.tickets USING btree (source_phone);


--
-- Name: ix_tickets_status; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_tickets_status ON public.tickets USING btree (status);


--
-- Name: ix_tickets_tenant_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_tickets_tenant_id ON public.tickets USING btree (tenant_id);


--
-- Name: ix_whatsapp_integrations_env_phone_number; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_whatsapp_integrations_env_phone_number ON public.whatsapp_integrations USING btree (environment, meta_phone_number_id);


--
-- Name: ix_whatsapp_integrations_environment; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_whatsapp_integrations_environment ON public.whatsapp_integrations USING btree (environment);


--
-- Name: ix_whatsapp_integrations_is_active; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_whatsapp_integrations_is_active ON public.whatsapp_integrations USING btree (is_active);


--
-- Name: ix_whatsapp_integrations_organization_id; Type: INDEX; Schema: public; Owner: rental_user
--

CREATE INDEX ix_whatsapp_integrations_organization_id ON public.whatsapp_integrations USING btree (organization_id);


--
-- Name: audit_logs audit_logs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: charges charges_lease_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.charges
    ADD CONSTRAINT charges_lease_id_fkey FOREIGN KEY (lease_id) REFERENCES public.leases(id) ON DELETE CASCADE;


--
-- Name: charges charges_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.charges
    ADD CONSTRAINT charges_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: checklist_item_templates checklist_item_templates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.checklist_item_templates
    ADD CONSTRAINT checklist_item_templates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: expense_attachments expense_attachments_expense_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.expense_attachments
    ADD CONSTRAINT expense_attachments_expense_id_fkey FOREIGN KEY (expense_id) REFERENCES public.expenses(id) ON DELETE CASCADE;


--
-- Name: expense_attachments expense_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.expense_attachments
    ADD CONSTRAINT expense_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: expense_categories expense_categories_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: expenses expenses_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: expenses expenses_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.expense_categories(id);


--
-- Name: expenses expenses_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: expenses expenses_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: expenses expenses_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: expenses expenses_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.units(id) ON DELETE SET NULL;


--
-- Name: expenses expenses_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id) ON DELETE SET NULL;


--
-- Name: messages fk_messages_ticket_id_tickets; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_messages_ticket_id_tickets FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE SET NULL;


--
-- Name: payment_review_items fk_payment_review_items_source_message_id; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.payment_review_items
    ADD CONSTRAINT fk_payment_review_items_source_message_id FOREIGN KEY (source_message_id) REFERENCES public.messages(id) ON DELETE SET NULL;


--
-- Name: tenants fk_tenants_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT fk_tenants_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ticket_messages fk_ticket_messages_recipient_id_users; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT fk_ticket_messages_recipient_id_users FOREIGN KEY (recipient_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tickets fk_tickets_assigned_to; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT fk_tickets_assigned_to FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: tickets fk_tickets_created_by; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT fk_tickets_created_by FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: tickets fk_tickets_property_id; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT fk_tickets_property_id FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE SET NULL;


--
-- Name: tickets fk_tickets_unit_id; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT fk_tickets_unit_id FOREIGN KEY (unit_id) REFERENCES public.units(id) ON DELETE SET NULL;


--
-- Name: inspection_items inspection_items_inspection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.inspection_items
    ADD CONSTRAINT inspection_items_inspection_id_fkey FOREIGN KEY (inspection_id) REFERENCES public.lease_inspections(id) ON DELETE CASCADE;


--
-- Name: inspection_notes inspection_notes_inspection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.inspection_notes
    ADD CONSTRAINT inspection_notes_inspection_id_fkey FOREIGN KEY (inspection_id) REFERENCES public.lease_inspections(id) ON DELETE CASCADE;


--
-- Name: inspection_notes inspection_notes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.inspection_notes
    ADD CONSTRAINT inspection_notes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: lease_inspections lease_inspections_inspector_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.lease_inspections
    ADD CONSTRAINT lease_inspections_inspector_user_id_fkey FOREIGN KEY (inspector_user_id) REFERENCES public.users(id);


--
-- Name: lease_inspections lease_inspections_lease_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.lease_inspections
    ADD CONSTRAINT lease_inspections_lease_id_fkey FOREIGN KEY (lease_id) REFERENCES public.leases(id) ON DELETE CASCADE;


--
-- Name: leases leases_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.leases
    ADD CONSTRAINT leases_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: leases leases_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.leases
    ADD CONSTRAINT leases_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: leases leases_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.leases
    ADD CONSTRAINT leases_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.units(id);


--
-- Name: messages messages_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: messages messages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: messages messages_triggered_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_triggered_by_user_id_fkey FOREIGN KEY (triggered_by_user_id) REFERENCES public.users(id);


--
-- Name: notification_preferences notification_preferences_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: organization_invitations organization_invitations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_invitations organization_invitations_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.organization_invitations
    ADD CONSTRAINT organization_invitations_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: organization_members organization_members_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT organization_members_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_members organization_members_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT organization_members_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: organization_members organization_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT organization_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: organizations organizations_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: otp_verifications otp_verifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.otp_verifications
    ADD CONSTRAINT otp_verifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_history password_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.password_history
    ADD CONSTRAINT password_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payment_review_items payment_review_items_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.payment_review_items
    ADD CONSTRAINT payment_review_items_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: payment_review_items payment_review_items_lease_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.payment_review_items
    ADD CONSTRAINT payment_review_items_lease_id_fkey FOREIGN KEY (lease_id) REFERENCES public.leases(id) ON DELETE SET NULL;


--
-- Name: payment_review_items payment_review_items_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.payment_review_items
    ADD CONSTRAINT payment_review_items_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: payment_review_items payment_review_items_resolution_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.payment_review_items
    ADD CONSTRAINT payment_review_items_resolution_payment_id_fkey FOREIGN KEY (resolution_payment_id) REFERENCES public.payments(id) ON DELETE SET NULL;


--
-- Name: payment_review_items payment_review_items_resolved_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.payment_review_items
    ADD CONSTRAINT payment_review_items_resolved_by_user_id_fkey FOREIGN KEY (resolved_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: payment_review_items payment_review_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.payment_review_items
    ADD CONSTRAINT payment_review_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: payments payments_lease_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_lease_id_fkey FOREIGN KEY (lease_id) REFERENCES public.leases(id) ON DELETE CASCADE;


--
-- Name: payments payments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: payments payments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: properties properties_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: property_finance_managers property_finance_managers_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.property_finance_managers
    ADD CONSTRAINT property_finance_managers_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: property_finance_managers property_finance_managers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.property_finance_managers
    ADD CONSTRAINT property_finance_managers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: property_managers property_managers_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.property_managers
    ADD CONSTRAINT property_managers_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: property_managers property_managers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.property_managers
    ADD CONSTRAINT property_managers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tenant_documents tenant_documents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.tenant_documents
    ADD CONSTRAINT tenant_documents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_documents tenant_documents_uploaded_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.tenant_documents
    ADD CONSTRAINT tenant_documents_uploaded_by_user_id_fkey FOREIGN KEY (uploaded_by_user_id) REFERENCES public.users(id);


--
-- Name: tenants tenants_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ticket_assignments ticket_assignments_assigned_from_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.ticket_assignments
    ADD CONSTRAINT ticket_assignments_assigned_from_fkey FOREIGN KEY (assigned_from) REFERENCES public.users(id);


--
-- Name: ticket_assignments ticket_assignments_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.ticket_assignments
    ADD CONSTRAINT ticket_assignments_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: ticket_assignments ticket_assignments_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.ticket_assignments
    ADD CONSTRAINT ticket_assignments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_attachments ticket_attachments_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.ticket_attachments
    ADD CONSTRAINT ticket_attachments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_attachments ticket_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.ticket_attachments
    ADD CONSTRAINT ticket_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: ticket_messages ticket_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: ticket_messages ticket_messages_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: tickets tickets_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: tickets tickets_source_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_source_message_id_fkey FOREIGN KEY (source_message_id) REFERENCES public.messages(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: units units_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: vendors vendors_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: whatsapp_integrations whatsapp_integrations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rental_user
--

ALTER TABLE ONLY public.whatsapp_integrations
    ADD CONSTRAINT whatsapp_integrations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

